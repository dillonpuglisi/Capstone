﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using System.Web.Services;

namespace ClientSiteTemplate
{
    public partial class Notes : System.Web.UI.Page
    {
        protected String noteid = "-1";
        protected String note = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            //FillFeed1();
            //FillFeed2();

            string value = Request.QueryString["noteid"];
            if (value != null && value != "" )//&& EditNote_TitleInput.Text=="") //if a noteid WAS passed through the url
            {
               // DebugLbl.Text = value;
                AddNoteDiv.Visible = false;
                EditNoteDiv.Visible = true;
                if (!Page.IsPostBack)
                    FillEditNoteDiv(value);
                noteid = value;

            }
            else
            {
                AddNoteDiv.Visible = true;
                EditNoteDiv.Visible = false;
            }
            
        }

        [WebMethod]
        //take in note info (title, note content, whether or not it should be encrypted and a password), and create Notes record
        public static String AddNote(String title, Boolean encrypt, String password, String note)
        {
            //check integrity of inputs
            if (MyString.IsBlank(title))
                return "Error: missing note title";
            if (MyString.IsBlank(note))
                return "Error: missing note content";
            if (encrypt && MyString.IsBlank(password))
                return "Error: cannot encrypt without password";

            try //wrapped in try/catch
            {
                //instantiate new SqlCommand with insert query
                SqlCommand cmd = new SqlCommand("INSERT INTO Notes (Title,DateCreated, Note,Active, encrypted) VALUES (@Title,@DateCreated,@Note,'true',@encrypted)");
                //attach parameter values to command obj
                cmd.Parameters.AddWithValue("@Title", title);
                cmd.Parameters.AddWithValue("@DateCreated", MyNet.GetEasternDateTime());
                cmd.Parameters.AddWithValue("@Note", (encrypt ? StringCipher.Encrypt(note, password) : note)); //if note should be encrypted per user input, encrypt it using given password
                
                String output = MySQL.CMDUpdate(cmd); //call external function that attempts to run query
                return output; //return results
            }
            catch (Exception exc) //upon failure, return exception info
            {
                // return false;
                return "Error: " + exc.Message + "; " + exc.StackTrace;
            }
        }

        //11/15/20 9:12a-9:15a
        [WebMethod]
        //take in note info (title, note content, whether or not it should be encrypted and a password), and create Notes record; return either Error OR NEW ID
        public static String AddNoteReturnID(String title, Boolean encrypt, String password, String note)
        {
            //check integrity of inputs
            if (MyString.IsBlank(title))
                return "Error: missing note title";
            if (MyString.IsBlank(note))
                return "Error: missing note content";
            if (encrypt && MyString.IsBlank(password))
                return "Error: cannot encrypt without password";

            try //wrapped in try/catch
            {
                //instantiate new SqlCommand with insert query
                string sqlstring = "INSERT INTO Notes (Title,DateCreated, Note,Active, encrypted) VALUES (@Title,@DateCreated,@Note,'true',@encrypted);SELECT SCOPE_IDENTITY() AS newID;";
                SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DP_DB"].ConnectionString);
                SqlCommand cmd = new SqlCommand(sqlstring, con);
                //attach parameter values to command obj
                cmd.Parameters.AddWithValue("@Title", title);
                cmd.Parameters.AddWithValue("@DateCreated", MyNet.GetEasternDateTime());
                cmd.Parameters.AddWithValue("@Note", (encrypt ? StringCipher.Encrypt(note, password) : note)); //if note should be encrypted per user input, encrypt it using given password
                con.Open();
                System.Data.SqlClient.SqlDataReader reader = cmd.ExecuteReader(); //need to execute as Reader so the new ID can be retrieved
                String newID = "-2";
                while (reader.Read())
                    newID = reader["newID"].ToString();

                con.Close();
                if (newID.Contains("-")) //if read() loop never run, return failure message
                    return "Error: no new ID returned: " + newID;
                return newID;
            }
            catch (Exception exc)
            {
               // MyException.HandleException(DateTime.Now, System.Reflection.MethodBase.GetCurrentMethod().Name, "", exc);
                return "Error: " + exc.Message + "; " + exc.StackTrace;
            }
        }

        /*protected void AddNewItemBtn_Click(object sender, EventArgs e)
        {
            bool output = AddNote(AddNote_TitleInput.Text, AddNote_EncryptInput.Checked, AddNote_EncryptPasswordInput.Text, AddNote_NotesInput.Text);
            if (output)
            {
                FillFeed1();
                FillFeed2();
                ClearNewItemForm();
                AddNote_OutputLbl.Text = "Success";
                AddNote_OutputLbl.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                AddNote_OutputLbl.Text = "Operation failed";
                AddNote_OutputLbl.ForeColor = System.Drawing.Color.Red;
            }

        }*/

        
        //11/15/20 9:16a-9:17a
        [WebMethod]
        public static String BuildFeed_NotesFrequentlyViewed()
        {
            return MyFeeds.Notes_FrequentlyViewed();
        }

        //11/15/20 9:17a-9:17a
        [WebMethod]
        public static String BuildFeed_NotesRecentlyCreatedActive()
        {
            return MyFeeds.Notes_RecentlyCreatedActive();
        }
        //11/15/20 9:17a-9:17a
        [WebMethod]
        public static String BuildFeed_NotesRecentlyUpdated()
        {
            return MyFeeds.Notes_RecentlyUpdated();
        }


        //protected void FillFeed1()
        //{
        //    Feed1Lbl3.Text = MyFeeds.Notes_FrequentlyViewed();

        //    Feed1Lbl1.Text = MyFeeds.Notes_RecentlyCreatedActive();

        //    Feed1Lbl2.Text = MyFeeds.Notes_RecentlyUpdated();
        //}

        //11/15/20 9:17a-9:18a
        [WebMethod]
        public static String BuildFeed_NotesActive()
        {
            return MyFeeds.Notes_Active();
        }

        //1/19/18
        //protected void FillFeed2()
        //{
        //    //Feed2Lbl1.Text = MyFeeds.Notes_All();
        //    Feed2Lbl1.Text = MyFeeds.Notes_Active();
        //}


        /*protected void ClearNewItemForm()
        {
            AddNote_TitleInput.Text = "";
            AddNote_NotesInput.Text = "";
        }*/

        protected void GenerateModal()
        {
            //modal_front.Attributes.Add("style", "display:none");
            modal_front.Style["display"] = "none";

        }

        /*protected void SaveNoteBtn_Click(object sender, EventArgs e)
        {
            String title = EditNote_TitleInput.Text;
            String note = "";
            if (EncryptedUpdate.Checked == true) //if the note is supposed to be encrypted
            {
                if (DecryptedUpdate.Checked == true)//and it  been decrypted
                    note = RunEncryption(Password.Text, EditNote_NoteInput.Text);
                //if it hasnt been decrypted, then editing is locked, button cant be clicked anyway

            }
            else
                note = EditNote_NoteInput.Text;
            //DebugLbl.Text = "NOTE:<br/> " + note;
            DateTime current = MyNet.GetEasternDateTime();
            SqlCommand cmd = new SqlCommand("update notes set title=@title, note=@note, dateupdated=@dateupdated,Active=@Active where noteid=@noteid");
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Parameters.AddWithValue("@note", note);
            cmd.Parameters.AddWithValue("@dateupdated", current);
            cmd.Parameters.AddWithValue("@noteid", Request.QueryString["noteid"]);
            cmd.Parameters.AddWithValue("@Active", EditNote_ActiveInput.Checked);
            //System.Diagnostics.Debug.WriteLine(MySQL.CMDUpdate(cmd));

            //String sql = "";
            //DebugLbl.Text = sql; 
            //SqlCommand cmd = new SqlCommand(sql);

            String output = MySQL.CMDUpdate(cmd);
            if (output == "Success")
            {
                RegisterNoteView(Request.QueryString["noteid"], note);//add view/change record

                //Response.Redirect(Request.RawUrl);
                FillFeed1();
                //ClearNewItemForm();
                EditNoteLbl.Text = "Note '" + title + "' updated " + current;//:<br/>title: " + title + "<br/>note: " + note;
                EditNoteLbl.ForeColor = System.Drawing.Color.Green;
                FillEditNoteDiv(Request.QueryString["noteid"]); //show update?
            }
            else
            {
                EditNoteLbl.Text = "Operation failed";
                EditNoteLbl.ForeColor = System.Drawing.Color.Red;
            }
        }*/
        
        //10/2/18 12:47p
        [WebMethod]
        //take in updated note info, attempt to update Notes record
        public static String UpdateNote(String NoteID, String Active, String Title, String Note)
        {
            //check integrity of inputs
            if (MyString.IsBlank(NoteID))
                return "Error: missing ID";
            if (MyString.IsBlank(Title))
                return "Error: missing title";
            if (MyString.IsBlank(Note))
                return "Error: missing note content";

            try //wrapped in try/catch
            {
                //instantiate new SqlCommand with update query
                SqlCommand cmd = new SqlCommand("update notes set title=@title, note=@note, dateupdated=@dateupdated,Active=@Active where noteid=@noteid");
                //attach parameter values to command obj
                cmd.Parameters.AddWithValue("@title", Title);
                cmd.Parameters.AddWithValue("@note", Note);
                cmd.Parameters.AddWithValue("@dateupdated", MyNet.GetEasternDateTime());
                cmd.Parameters.AddWithValue("@noteid", NoteID);
                cmd.Parameters.AddWithValue("@Active", Active);
                String result = MySQL.CMDUpdate(cmd); //call external function that attempts to run query
                if (result == "Success")
                {
                    RegisterNoteView(NoteID, Note); //if note update successful, register the change in the auditing log
                    return "Success";
                }
                else
                    return result;
            }
            catch (Exception exc) //upon failure, return exception info
            {
                return "Error: " + exc.Message + "; " + exc.StackTrace;
            }


        }

        //11/7/18 2:37p
        public static void RegisterNoteView(String NoteID, String NoteChange)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO NotesViewLog (NoteID, timestamp, NoteChange) VALUES (@NoteID, @timestamp, @NoteChange)");
            cmd.Parameters.AddWithValue("@NoteID", NoteID);
            cmd.Parameters.AddWithValue("@timestamp", MyNet.GetEasternDateTime());
            cmd.Parameters.AddWithValue("@NoteChange", MySQL.CheckDBNull(NoteChange));
            String output = MySQL.CMDUpdate(cmd);
        }

        protected void FillEditNoteDiv(String noteid)
        {

            SqlCommand cmd = new SqlCommand("select title, datecreated, note, dateupdated,active, encrypted from Notes where noteid=@noteid");
            cmd.Parameters.AddWithValue("@noteid", noteid);
            DataSet NotesDS = MySQL.CMDSelect(cmd);

            RegisterNoteView(noteid, null);//add view record

            if (NotesDS.Tables.Count == 0)
                Feed1Lbl1.Text = "Error retrieving data.";
            else
            {
                System.Diagnostics.Debug.WriteLine("count: " + NotesDS.Tables[0].Rows.Count);
                if (NotesDS.Tables[0].Rows.Count == 0)
                    EditNote_TitleInput.Text = "**ERROR RETRIEVING NOTE**";
                else
                {
                    EditNote_TitleInput.Text = NotesDS.Tables[0].Rows[0][0].ToString();
                    ReadDateLbl.Text = NotesDS.Tables[0].Rows[0][1].ToString();
                    UpdateDateLbl.Text = NotesDS.Tables[0].Rows[0][3].ToString();
                    //System.Diagnostics.Debug.WriteLine(NotesDS.Tables[0].Rows[0][5].ToString());
                    if (NotesDS.Tables[0].Rows[0][5].ToString()=="1" || NotesDS.Tables[0].Rows[0][5].ToString() == "True") //if its encrypted
                    {
                        DecryptSpan.Visible = true;
                        
                        EncryptedUpdate.Checked = Convert.ToBoolean(NotesDS.Tables[0].Rows[0][5].ToString());
                        DecryptedUpdate.Checked = false;
                        EditButtons.Visible = false;
                        EditNote_NoteInput.Enabled = false; //dont allow textbox to be edited, even though buttons cant be clicked anyway
                        AutosaveSpan.Visible = false;
                    }
                    else
                    {
                        DecryptSpan.Visible = false; //hide buttons
                        EditNote_NoteInput.Enabled = true;

                    }
                        
                    EditNote_NoteInput.Text = NotesDS.Tables[0].Rows[0][2].ToString();
                    note = NotesDS.Tables[0].Rows[0][2].ToString();
                    //int val = MyString.CountInstances(NotesDS.Tables[0].Rows[0][2].ToString(), "\n", false);
                    //EditNote_NoteInput.Height = val * 12 ;
                    //DebugLbl.Text = "Height: " + val + ";" + EditNote_NoteInput.Height; //-->Height: 49;588px, yet the height isnt actually changed
                    EditNote_ActiveInput.Checked = Convert.ToBoolean(NotesDS.Tables[0].Rows[0][4].ToString());
                }
            }
        }

        protected void DeleteNoteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("delete from notes where noteid=@noteid");
                cmd.Parameters.AddWithValue("@noteid", Request.QueryString["noteid"]);
                //System.Diagnostics.Debug.WriteLine(MySQL.CMDUpdate(cmd));

                //String sql = "";
                //DebugLbl.Text = sql; 
                //SqlCommand cmd = new SqlCommand(sql);

                String output = MySQL.CMDUpdate(cmd);
                if (output != "Success")
                {
                    throw new Exception(output);
                }


                //EditNoteLbl.Text = "Note Deleted"; //no point, since redirect
                //EditNoteLbl.ForeColor = System.Drawing.Color.Green;
                //Response.Write("<script>alert('Note Deleted')</script>"); //doesnt work
                Response.Redirect("Notes.aspx", false);

            }
            catch (Exception exc)
            {
                EditNoteLbl.Text = "Deletion Failed";
                EditNoteLbl.ForeColor = System.Drawing.Color.Red;
            }
        }

        //10/3/18 1:51p
        protected String RunEncryption(String password, String plaintext)
        {
            return StringCipher.Encrypt(plaintext, password);
        }

        //10/3/18 1:57p
        protected String RunDecryption(String password, String encryptedstring)
        {
            return StringCipher.Decrypt(encryptedstring, password);
        }

        protected void DecryptBtn_Click(object sender, EventArgs e)
        {
            EditNote_NoteInput.Text = StringCipher.Decrypt(EditNote_NoteInput.Text, Password.Text);
            DecryptedUpdate.Checked = true;
            EncryptedUpdate.Checked = true;
            DecryptSpan.Visible = false;
            EditButtons.Visible = true;
            EditNote_NoteInput.Enabled = true;
        }

        //10/26/18 12:50p
        //copied from Shows.NewShowLogSubmitBtn_Click()
        protected void ParseWatchlog_Click(object sender, EventArgs e)
        {
            String log = EditNote_NoteInput.Text;
            List<String> lines = MyList.ArrayToList(MyString.ReplaceSubstring(log, "\r\n", "\r", false).Split('\r'));
            String output = "";
            List<List<String>> output2 = new List<List<String>>();

            String date = MyString.CutSubstring(lines[0], "Watched");

            for (int i = 1; i < lines.Count; i++)
            {
                //output += MyString.CutSubstring(lines[0],"Watched") + "\t";
                List<String> watchItem = new List<string>();
                //watchItem.Add(MyString.CutSubstring(lines[0], "Watched"));
                while (i < lines.Count && lines[i] != "")
                {
                    System.Diagnostics.Debug.WriteLine("i: [" + i + "]: " + lines[i]);
                    watchItem.Add(lines[i]);
                    i++;
                }
                output2.Add(watchItem);
            }

            List<ViewingLog.WatchLogItem> wlis = new List<ViewingLog.WatchLogItem>();
            for (int i = 0; i < output2.Count; i++)
            {
                ViewingLog.WatchLogItem wli = new ViewingLog.WatchLogItem();

                //accounts for empty lines (double newlines in input)
                if (output2[i].Count == 0)
                    i++;

                //DATE
                wli.date = date.Trim();

                //COUNTER
                if (output2[i][0].Contains("1st?") || output2[i][0].Contains("1st ?"))
                {
                    wli.counter = "1st?";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "1st?");
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "1st ?");
                }
                else if (output2[i][0].Contains("1st"))
                {
                    wli.counter = "1st";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "1st");
                }
                else if (output2[i][0].Contains("2nd?") || output2[i][0].Contains("2nd ?"))
                {
                    wli.counter = "2nd?";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "2nd?");
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "2nd ?");
                }
                else if (output2[i][0].Contains("2nd"))
                {
                    wli.counter = "2nd";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "2nd");
                }
                else if (output2[i][0].Contains("3rd?") || output2[i][0].Contains("3rd ?"))
                {
                    wli.counter = "3rd?";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "3rd?");
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "3rd ?");
                }
                else if (output2[i][0].Contains("3rd"))
                {
                    wli.counter = "3rd";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "3rd");
                }

                //STARTTIME
                if (output2[i][0].Contains(":"))
                {
                    String time = ViewingLog.ParseStartTime(output2[i][0]);
                    if (time != "")
                    {
                        output2[i][0] = MyString.CutSubstring(output2[i][0], time);
                        if (time.Contains("-"))
                        {
                            time = MyString.ReplaceSubstring(time, "-", "", false); //remove hyphens, such as when input includes '9:00p-10:00p'
                            //MyString.ReplaceSubstring(output2[i][0], "-", "", false);
                        }

                        if (ViewingLog.numbers.Contains(time.Substring(time.Length - 1))) //if it doesnt have a 'a' or 'p', if it ends with a number
                            time = time + "p"; //assume pm?
                        wli.starttime = time;

                    }

                    String time2 = ViewingLog.ParseStartTime(output2[i][0]);
                    if (time2 != "")
                    {
                        output2[i][0] = MyString.CutSubstring(output2[i][0], time2);
                        if (time2.Contains("-"))
                        {
                            time2 = MyString.ReplaceSubstring(time2, "-", "", false); //remove hyphens, such as when input includes '9:00p-10:00p'
                            //MyString.ReplaceSubstring(output2[i][0], "-", "", false);  //redundant? as it would be run above
                        }

                        if (ViewingLog.numbers.Contains(time2.Substring(time2.Length - 1))) //if it doesnt have a 'a' or 'p', if it ends with a number
                            time2 = time2 + "p"; //assume pm?
                        wli.endtime = time2;

                    }


                }

                //NEW
                if (output2[i][0].Contains("new"))
                {
                    wli.newb = "new";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "new");
                }

                //TYPE
                if (output2[i][0].Contains("movie"))
                {
                    wli.type = "movie";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "movie");

                    if (output2[i][0].Contains("tv")) //if it includes a tv
                    {
                        wli.location = "tv";
                        output2[i][0] = MyString.CutSubstring(output2[i][0], "tv");


                    }
                }
                else if (output2[i][0].Contains("tv"))
                {
                    wli.type = "tv";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "tv");

                    if (output2[i][0].Contains("tv")) //if it includes a SECOND tv
                    {
                        wli.location = "tv";
                        output2[i][0] = MyString.CutSubstring(output2[i][0], "tv");


                    }
                }

                //LOCATION
                if (output2[i][0].Contains("from downloads"))
                {
                    wli.location = "from downloads";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "from downloads");
                }
                else if (output2[i][0].Contains("downloads"))
                {
                    wli.location = "from downloads";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "downloads");
                }
                if (output2[i][0].Contains("netflix"))
                {
                    wli.location = "Netflix";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "netflix");
                }
                if (output2[i][0].Contains("amazon prime"))
                {
                    wli.location = "Amazon Prime";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "amazon prime");
                }
                if (output2[i][0].Contains("hulu"))
                {
                    wli.location = "Hulu";
                    output2[i][0] = MyString.CutSubstring(output2[i][0], "hulu");
                }

                //TITLE
                wli.title = output2[i][0].Trim(); //whatever is left is most of the title
                wli.title = MyString.ReplaceSubstrings(wli.title, new List<List<string>> {
                    new List<string>{"Last man standing","Last Man Standing"},new List<string>{"Doctor who","Doctor Who"},
                    new List<string>{"the flash","The Flash"}, new List<string>{"Fresh off the boat","Fresh Off the Boat"},
                    new List<string>{"Last week tonight with john oliver","Last Week Tonight with John Oliver"}, new List<string>{"Family guy","Family Guy"},
                    new List<string>{"Walking dead","The Walking Dead"}, new List<string>{"the the walking dead","The Walking Dead"},
                    new List<string>{"blackish","Blackish"}, new List<string>{"Splitting up together","Splitting Up Together"},
                    new List<string>{"Star Wars resistance","Star Wars Resistance"}
                } , false);

                List<String> logs = new List<string>();
                if (output2[i].Count != 1) //otherwise the title gets put in as a log
                {
                    for (int n = 1; n < output2[i].Count - 1; n++)
                        logs.Add(output2[i][n]);

                    if (output2[i][output2[i].Count - 1].StartsWith("ended")) //if the last log is the "ended [time]"
                        wli.endtime = MyString.CutSubstring(output2[i][output2[i].Count - 1], "ended");
                    else if (output2[i][output2[i].Count - 1].StartsWith("Ended")) //if the last log is the "ended [time]"
                        wli.endtime = MyString.CutSubstring(output2[i][output2[i].Count - 1], "Ended");
                    else if (output2[i][output2[i].Count - 1].StartsWith("Enddd")) //if the last log is the "ended [time]"
                        wli.endtime = MyString.CutSubstring(output2[i][output2[i].Count - 1], "Enddd");
                    else
                        logs.Add(output2[i][output2[i].Count - 1]);
                }




                wli.logs = logs;
                wlis.Add(wli);
            }
            System.Diagnostics.Debug.WriteLine("done");
            String final = "";
            foreach (ViewingLog.WatchLogItem wli in wlis)
                final += wli.Print();// + "<br/>"; //theyre split by <pre>s so <br/> is not needed
            final += "<br/><br/>";


            //String notetitle = "Watched " + date + "_import";

            // Notes notespage = new Notes();
            //bool note_added = notespage.AddNote(notetitle, false, "", final);

            //if (note_added)
            //    final = "CREATED NOTE: " + notetitle + "<br/>" + final;
            // else
            //    final = "FAILED TO CREATE NOTE<br/>" + final;

            ParseLbl.Text = final;
        }


        //Notes//NoteID, Title, Note, DateCreated, DateUpdated, Active, encrypted

        //11/15/2020 8:40 AM
        [WebMethod]
        //take in all info required to either add or edit note record, then run either Add or Update function
        public static String AddEditNote(String NoteID, String Title, String Note, String Active, Boolean encrypt, String Password) //, String DateCreated, String DateUpdated,
        {
            //permission controls not yet implemented in this site
            //MyEmployees.EmployeeObj currentuser = new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser());
            //if (!currentuser.Admin)
            //    return "Error: INSUFFICIENT PERMISSIONS";

            bool doNew = (NoteID == ""); //determine operation based on presence of NoteID
            if (!doNew)
                return UpdateNote(NoteID, Active, Title, Note);
            else
                return AddNote(Title, encrypt, Password, Note);


            //more advanced query system to be refined/implemented later
            /*try
            {
                string sqlstring = (doNew) ? "INSERT INTO [Notes] (Title, Note, DateCreated, DateUpdated, Active, encrypted) VALUES (@Title, @Note, @DateCreated, @DateUpdated, @Active, @encrypted)" :
             "UPDATE [Notes] SET Title=@Title, Note=@Note, DateCreated=@DateCreated, DateUpdated=@DateUpdated, Active=@Active, encrypted=@encrypted WHERE NoteID=@NoteID";
                MySQL.SqlProcess sql = new MySQL.SqlProcess();
                sql.setQuery(sqlstring);
                if (!doNew) //only include ID if we're running an update query
                    sql.AddParam("@NoteID", NoteID, false, false);
                sql.AddParam("@Title", Title);
                sql.AddParam("@Note", Note);
                sql.AddParam("@DateCreated", DateCreated);
                sql.AddParam("@DateUpdated", DateUpdated);
                sql.AddParam("@Active", Active);
                sql.AddParam("@encrypted", encrypted);
                sql.OpenConn();
                int rowsaffected = sql.Execute_CountRows();
                sql.CloseConn();
                if (rowsaffected == 0)
                    return "Error: no rows updated";
                else
                    return "Success";
            }
            catch (Exception exc)
            {
               // MyException.HandleException(DateTime.Now, new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser()).employeeid.ToString(), System.Reflection.MethodBase.GetCurrentMethod().Name, "", exc);
                return "Error: " + exc.Message + "; " + exc.StackTrace;
            }
            */
        }


        //11/15/2020 8:40 AM
        [WebMethod]
        public static String DeleteNote(String NoteID)
        {
            //MyEmployees.EmployeeObj currentuser = new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser());
            //if (!currentuser.Admin)
            //    return "Error: INSUFFICIENT PERMISSIONS";

            try
            {
                MySQL.SqlProcess sql = new MySQL.SqlProcess();
                sql.setQuery("DELETE FROM Notes WHERE NoteID=@NoteID");
                sql.AddParam("@NoteID", NoteID, false, false);
                sql.OpenConn();
                int rowsaffected = sql.Execute_CountRows();
                sql.CloseConn();
                if (rowsaffected == 0)
                    return "Error: no rows deleted";
                else
                    return "Success";
            }
            catch (Exception exc)
            {
               // MyException.HandleException(DateTime.Now, new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser()).employeeid.ToString(), System.Reflection.MethodBase.GetCurrentMethod().Name, "", exc);
                return "Error: " + exc.Message + "; " + exc.StackTrace;
            }
        }


        //11/15/2020 8:40 AM
        public class NoteObj
        {
            public String NoteID { get; set; }
            public String Title { get; set; }
            public String Note { get; set; }
            public String DateCreated { get; set; }
            public String DateUpdated { get; set; }
            public String Active { get; set; }
            public String encrypted { get; set; }
            public Exception exc { get; set; }
            public NoteObj()
            {
                NoteID = "";
                Title = "";
                Note = "";
                DateCreated = "";
                DateUpdated = "";
                Active = "";
                encrypted = "";
            }
            public NoteObj(String NoteID, String Title, String Note, String DateCreated, String DateUpdated, String Active, String encrypted)
            {
                this.NoteID = NoteID;
                this.Title = Title;
                this.Note = Note;
                this.DateCreated = DateCreated;
                this.DateUpdated = DateUpdated;
                this.Active = Active;
                this.encrypted = encrypted;
            }
            public NoteObj(Exception exc)
            {
                this.exc = exc;
            }
        }


        //11/15/2020 8:40 AM
        public class NoteContainer
        {
            public List<NoteObj> items { get; set; }
            public Exception exc { get; set; }
            public NoteContainer()
            {
                items = new List<NoteObj>();
            }
            public NoteContainer(Exception exc)
            {
                this.exc = exc;
            }
            public List<List<String>> ToList()
            {
                if (exc != null || items.Count == 0)
                    return new List<List<string>>();
                List<List<String>> output = new List<List<string>>();
                foreach (NoteObj item in items)
                    output.Add(new List<string> { item.NoteID, item.Title });
                return output;
            }
        }


        //11/15/2020 8:40 AM
        public static NoteContainer GetNotes(String NoteID, String Title, String Active) //, String Note, String DateCreated, String DateUpdated, , String encrypted
        {
            try
            {
                String sqlstring = "SELECT NoteID, Title, Note, DateCreated, DateUpdated, Active, encrypted FROM [Notes]";
                MySQL.SqlProcess sql = new MySQL.SqlProcess();
                sql.setQuery(sqlstring);
                //sql.AddConditional("NoteID", NoteID);
                //sql.AddConditional("Title", Title);
                //sql.AddConditional("Note", Note);
                //sql.AddConditional("DateCreated", DateCreated);
                //sql.AddConditional("DateUpdated", DateUpdated);
                //sql.AddConditional("Active", Active);
                //sql.AddConditional("encrypted", encrypted);
                NoteContainer output = new NoteContainer();
                sql.OpenConn();
                SqlDataReader reader = sql.Execute_Read();
                while (reader.Read())
                {
                    output.items.Add(new NoteObj(reader["NoteID"].ToString(), reader["Title"].ToString(), reader["Note"].ToString(), 
                        reader["DateCreated"].ToString(), reader["DateUpdated"].ToString(), 
                        reader["Active"].ToString(), reader["encrypted"].ToString()));
                }
                sql.CloseConn();
                return output;
            }
            catch (Exception exc)
            {
                //MyException.HandleException(DateTime.Now, new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser()).employeeid.ToString(), System.Reflection.MethodBase.GetCurrentMethod().Name, "", exc);
                return new NoteContainer(exc);
            }
        }


        //11/15/2020 8:40 AM
        //function to build html table of Note records 
        [WebMethod]
        public static String BuildTable_Note(String NoteID, String Title, String Active) //, String Note, String DateCreated, String DateUpdated, String encrypted
        {
            NoteContainer all = GetNotes(NoteID, Title, Active); //Note, DateCreated, DateUpdated, , encrypted
            if (all.exc != null)
                return "Error: " + all.exc.Message + "; " + all.exc.StackTrace;
            else if (all.items.Count == 0)
                return "--None--";
            else
            {
                String output = "";
                output += "<table class='BasicTable'>";
                output += "<thead><tr>";
                output += "<th>NoteID</th>";
                output += "<th>Title</th>";
                output += "<th>Note</th>";
                output += "<th>DateCreated</th>";
                output += "<th>DateUpdated</th>";
                output += "<th>Active</th>";
                output += "<th>encrypted</th>";
                output += "</tr></thead>";
                output += "<tbody>";
                for (int i = 0; i < all.items.Count; i++)
                {
                    output += "<tr>";
                    output += "<td>" + all.items[i].NoteID + "</td>";
                    output += "<td>" + all.items[i].Title + "</td>";
                    output += "<td>" + all.items[i].Note + "</td>";
                    output += "<td>" + all.items[i].DateCreated + "</td>";
                    output += "<td>" + all.items[i].DateUpdated + "</td>";
                    output += "<td>" + all.items[i].Active + "</td>";
                    output += "<td>" + all.items[i].encrypted + "</td>";
                    output += "</tr>";
                }
                output += "</tbody>";
                output += "</table>";
                return output;
            }
        }


        //11/15/2020 8:40:50 AM
        //build the form to either add or edit a Note record
        [WebMethod]
        public static String BuildForm_AddEditNote(String NoteID)
        {
            //MyEmployees.EmployeeObj currentuser = new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser());
            //if (!currentuser.Admin)
            //    return "Error: INSUFFICIENT PERMISSIONS";
            bool doNew = (NoteID == "");
            NoteObj item = new NoteObj();
            if (!doNew)
            {
                NoteContainer all = GetNotes(NoteID, "", "");
                if (all.exc != null)
                    return "Error: " + all.exc.Message + "; " + all.exc.StackTrace;
                else if (all.items.Count == 0)
                    return "Error: unrecognized ID";
                else if (all.items.Count > 1)
                    return "Error: multiple records found under this ID";
                item = all.items[0];
            }
            String output = (doNew) ? "<h3>Add Note</h3>" : "<h3>Edit Note #" + item.NoteID + "</h3>";
            output += "<table class='BasicTable'>";
            output += "<thead><tr>";
            output += "        <th>Title: </th><td><input type='text' value='" + item.Title + "' id='AddEditNote_AddNote_TitleInput" + item.NoteID + "'/></td>";
            output += "        <th>Note: </th><td><input type='text' value='" + item.Note + "' id='AddEditNote_NoteInput" + item.NoteID + "'/></td>";
            output += "        <th>DateCreated: </th><td><input type='text' value='" + item.DateCreated + "' id='AddEditNote_DateCreatedInput" + item.NoteID + "'/></td>";
            output += "        <th>DateUpdated: </th><td><input type='text' value='" + item.DateUpdated + "' id='AddEditNote_DateUpdatedInput" + item.NoteID + "'/></td>";
            output += "        <th>Active: </th><td><input type='text' value='" + item.Active + "' id='AddEditNote_ActiveInput" + item.NoteID + "'/></td>";
            output += "        <th>encrypted: </th><td><input type='text' value='" + item.encrypted + "' id='AddEditNote_encryptedInput" + item.NoteID + "'/></td>";
            output += "</tr></thead>";
            output += "</table>";
            String buttontext = (NoteID == "") ? "Add Note" : "Save Changes";
            output += "<input type='button' value='" + buttontext + "' onclick=\"AddEditNote_Submit('" + NoteID + "')\" />";
            return output;
        }
    }
}