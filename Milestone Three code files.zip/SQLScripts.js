﻿//var table = "ToolDefinitions"
//var fields = ["ToolDefinitionsID","CategoryID","TypeID","SeriesID","SizeDiameter","Style","Cut","ProjectionLength","Other"]
//  FIRST FIELD IS ID
//var fields = "ToolOrderID,ToolRequestID,RequestDate,OrderDate,DueDate,VendorID,OrderingEmployeeID".split(",")



//builds SQL select query given table name and list of fields
//2/11/20 4:04p UPDATED to account for fields or table names with spaces in them
function BuildSelectQuery(table, fields) {
    var output = "SELECT ";
    for (var i = 0; i < fields.length; i++) {
        field = $.trim(fields[i]);
        if (field.indexOf(" ") != -1)
            output += "[" + field + "], ";
        else
            output += field + ", ";
    }
    output = output.substring(0, output.length - 2);
    output += " FROM [" + table + "]";
    return output;
}

//builds SQL insert query given table name and list of fields
//2/11/20 4:10p UPDATED to account for fields or table names with spaces in them
function BuildInsertQuery(table, fields) {
    var output = "INSERT INTO [" + table + "] (";
    for (var i = 1; i < fields.length; i++) { //i=1 becase skip first field, its the ID
        field = $.trim(fields[i]);
        if (field.indexOf(" ") != -1)
            output += "[" + field + "], ";
        else
            output += field + ", ";
    }
    output = output.substring(0, output.length - 2);
    output += ") VALUES (";
    for (var i = 1; i < fields.length; i++) {
        field = $.trim(fields[i]);
        if (field.indexOf(" ") != -1)
            output += "@" + field.replace(" ","") + ", ";
        else
            output += "@" + field + ", ";
    }
    output = output.substring(0, output.length - 2);
    output += ")";
    return output;
}

//builds SQL update query given table name and list of fields
//2/11/20 4:10p UPDATED to account for fields or table names with spaces in them
function BuildUpdateQuery(table, fields) {
    //console.log("BuildUpdateQuery: ",  table, fields);
    var output = "UPDATE [" + table + "] SET ";
    //console.log("1: ", output);
    for (var i = 1; i < fields.length; i++) {
        field = $.trim(fields[i]);
        if (field.indexOf(" ") != -1)
            output += "[" + field + "]=@" + field.replace(" ", "") + ", ";
        else
            output += field + "=@" + field + ", ";
    }
    //console.log("2: ", output);
    output = output.substring(0, output.length - 2);
    output += " WHERE ";
   // console.log("3: ", output);
    if (fields[0].indexOf(" ") != -1)
        output += "[" + fields[0] + "]=@" + fields[0].replace(" ", "") + ", ";
    else
        output += fields[0] + "=@" + fields[0];
    //console.log("4: ", output);
    return output;
}

//builds SQL delete query given table name and list of fields
//2/11/20 4:10p UPDATED to account for fields or table names with spaces in them
function BuildDeleteQuery(table, field) {
    var output = "DELETE FROM ";
    if (table.indexOf(" ") != -1)
        output += "[" + table + "]";
    else
        output += table;
    output += " WHERE ";
    field = $.trim(field);
    if (field.indexOf(" ") != -1)
        output += "[" + field + "] = @" + field.replace(" ", "");
    else
        output += field + "=@" + field;
    return output;
}




//builds C# select function shell given table name and list of fields
function BuildSelectFunction(table, fields, connectionstring) {
    var output = "//" + GetDate();
    output += "\npublic static List<List<String>> Get" + table + "() \n";
    output += "{\n";
    output += "try {\n";
    output += "String sqlstring = \"" + BuildSelectQuery(table, fields) + "\";\n";
    output += "System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings[\"" + connectionstring + "\"].ToString());\n";
    output += "System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand(sqlstring, con);\n";
    output += "System.Data.SqlClient.SqlDataReader reader;\n";
    output += "con.Open();\n";
    output += "reader = comm.ExecuteReader();\n";
    output += "List<List<String>> outputlist = new List<List<String>>();\n";
    output += "while (reader.Read())\n";
    output += "{\n";
    output += "List<String> row = new List<String>();\n";
    for (var i = 0; i < fields.length; i++)
        output += "row.Add(reader[\"" + fields[i] + "\"].ToString());\n";
    output += "outputlist.Add(row);\n";
    output += "}\n";
    output += "con.Close(); \n";
    output += "return outputlist; \n";
    output += "}\n";
    output += "catch (Exception exc)";
    output += "{\n";
    output += "List<String> output = new List<String>();\n";
    output += "output.Add(exc.Message);\n";
    output += "output.Add(exc.StackTrace);\n";
    output += "List<List<String>> output2 = new List<List<String>>();\n";
    output += "output2.Add(output);\n";
    output += "return output2;\n";
    output += "}\n";
    output += "}\n";
    return output;
}

//builds C# insert function shell given table name and list of fields
function BuildInsertFunction(table, objectname, fields, connectionstring) {
    var output = "//" + GetDate();
    output += "\n[WebMethod]\npublic static String Add" + objectname + "(";
    for (var i = 1; i < fields.length; i++)
        output += "String " + fields[i] + ",";
    output = output.substring(0, output.length - 1);
    output += ") \n";
    output += "{\n";
    output += "try {\n";
    output += "    string sqlstring = \"" + BuildInsertQuery(table, fields) + "\";\n";
    output += "    SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings[\"" + connectionstring + "\"].ConnectionString);\n";
    output += "    SqlCommand com = new SqlCommand(sqlstring, con);\n";

    for (var i = 1; i < fields.length; i++)  //skip the ID field
        output += "    com.Parameters.AddWithValue(\"@" + fields[i] + "\", " + fields[i] + ");\n";

    output += "    con.Open();\n";
    output += "    int rowsaffected = com.ExecuteNonQuery(); \n";
    output += "    con.Close();\n";
    output += "     if (rowsaffected == 0)\n";
    output += "        return \"Error: no rows inserted\";\n";
    output += "    else\n";
    output += "        return \"Success\";\n";
    output += "}\n";
    output += "catch (Exception exc)\n";
    output += "{\n";
    output += "    return \"Error: \" + exc.Message + \"; \" + exc.StackTrace;\n";
    output += "}\n";
    output += "}\n";
    return output;
}

//builds C# update function shell given table name and list of fields
function BuildUpdateFunction(table, objectname, fields, connectionstring) {
    var output = "//" + GetDate();
    output += "\n[WebMethod]\npublic static String Update" + objectname + "(";
    for (var i = 0; i < fields.length; i++)
        output += "String " + fields[i] + ",";
    output = output.substring(0, output.length - 1);
    output += ") \n";
    output += "{\n";
    output += "try {\n";
    output += "    string sqlstring = \"" + BuildUpdateQuery(table, fields) + "\";\n";
    output += "    SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings[\"" + connectionstring + "\"].ConnectionString);\n";
    output += "    SqlCommand com = new SqlCommand(sqlstring, con);\n";

    for (var i = 0; i < fields.length; i++)
        output += "    com.Parameters.AddWithValue(\"@" + fields[i] + "\", " + fields[i] + ");\n";

    output += "    con.Open();\n";
    output += "    int rowsaffected = com.ExecuteNonQuery(); \n";
    output += "    con.Close();\n";
    output += "     if (rowsaffected == 0)\n";
    output += "        return \"Error: no rows updated\";\n";
    output += "    else\n";
    output += "        return \"Success\";\n";
    output += "}\n";
    output += "catch (Exception exc)\n";
    output += "{\n";
    output += "    return \"Error: \" + exc.Message + \"; \" + exc.StackTrace;\n";
    output += "}\n";
    output += "}\n";
    return output;
}

//2/11/20 3:55p-3:59p
//builds C# add/edit function shell given table name and list of fields
function BuildAddEditFunction2(table, objectname, fields, connectionstring) {
    var output = "//" + GetDate();
    output += "\n[WebMethod]\npublic static String AddEdit" + objectname + "(";
    for (var i = 0; i < fields.length; i++)
        output += "String " + $.trim(fields[i]).replace(" ","") + ",";
    output = output.substring(0, output.length - 1);
    output += ") \n";
    output += "{\n";
    output += "MyEmployees.EmployeeObj currentuser = new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser());\n";
    output += "if (!currentuser.Admin)\n";
    output += 'return "Error: INSUFFICIENT PERMISSIONS";\n\n';
    output += 'bool doNew = (' + fields[0] + ' == "");\n';
    output += "try {\n";
    output += "    string sqlstring = (doNew) ? \"" + BuildInsertQuery(table, fields) + "\" :\n \"" + BuildUpdateQuery(table, fields) + "\";\n";
    output += "    SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings[\"" + connectionstring + "\"].ConnectionString);\n";
    output += "    SqlCommand com = new SqlCommand(sqlstring, con);\n";
    output += "if (!doNew) //only include ID if we're running an update query\n";
    output += "    com.Parameters.AddWithValue(\"@" + $.trim(fields[0]).replace(" ", "") + "\", " + $.trim(fields[0]) + ");\n";
    for (var i = 1; i < fields.length; i++)
        output += "    com.Parameters.AddWithValue(\"@" + $.trim(fields[i]).replace(" ", "") + "\", " + $.trim(fields[i]).replace(" ","") + ");\n";

    output += "    con.Open();\n";
    output += "    int rowsaffected = com.ExecuteNonQuery(); \n";
    output += "    con.Close();\n";
    output += "     if (rowsaffected == 0)\n";
    output += "        return \"Error: no rows updated\";\n";
    output += "    else\n";
    output += "        return \"Success\";\n";
    output += "}\n";
    output += "catch (Exception exc)\n";
    output += "{\n";
    output += '    MyException.HandleException(DateTime.Now, new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser()).employeeid.ToString(), System.Reflection.MethodBase.GetCurrentMethod().Name, "", exc);\n';
    output += "    return \"Error: \" + exc.Message + \"; \" + exc.StackTrace;\n";
    output += "}\n";
    output += "}\n";
    return output;
}

//5/6/20 9:18a-9:20a
//using SQLProcess
//builds C# function for executing an insert or update query on a table
function BuildAddEditFunction3(table, objectname, fields, fieldcustomizations) {
    var output = "//" + GetDate();
    output += "\n[WebMethod]\npublic static String AddEdit" + objectname + "(";
    for (var i = 0; i < fields.length; i++) //process all table fields into String input params
    {
        if (fieldcustomizations[i].isEditable || fieldcustomizations[i].isPk) {
            if (fieldcustomizations[i].datatype == "Bit")
                output += "bool " + $.trim(fields[i]).replace(" ", "") + ",";
            else
                output += "String " + $.trim(fields[i]).replace(" ", "") + ",";
        }
    }
    output = output.substring(0, output.length - 1);
    output += ") \n";
    output += "{\n";
    output += "MyEmployees.EmployeeObj currentuser = new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser());\n";
    output += "if (!currentuser.Admin)\n";
    output += 'return "Error: INSUFFICIENT PERMISSIONS";\n\n'; //where applicable, make function admin access only
    output += 'bool doNew = (' + fields[0] + ' == "");\n'; //determine if insert or update operation based on instantiation of pK field
    output += "try {\n";
    output += "    string sqlstring = (doNew) ? \"" + BuildInsertQuery(table, fields) + "\" :\n \"" + BuildUpdateQuery(table, fields) + "\";\n"; //set query accordinly
    output += "    MySQL.SqlProcess sql = new MySQL.SqlProcess();\n";
    output += "    sql.setQuery(sqlstring);\n";
    output += "if (!doNew) //only include ID if we're running an update query\n";
    output += "    sql.AddParam(\"@" + $.trim(fields[0]).replace(" ", "") + "\", " + $.trim(fields[0]) + ",false,false);\n";
    for (var i = 1; i < fields.length; i++) //iterate through fields list and add to query object as params
    {
        if (fieldcustomizations[i].isEditable ) 
            output += "    sql.AddParam(\"@" + $.trim(fields[i]).replace(" ", "") + "\", " + $.trim(fields[i]).replace(" ", "") + ");\n";
    }
    output += "    sql.OpenConn();\n";
    output += "    int rowsaffected = sql.Execute_CountRows(); \n"; //execute query using Sqlprocess object
    output += "    sql.CloseConn();\n";
    output += "     if (rowsaffected == 0)\n";
    output += "        return \"Error: no rows updated\";\n";
    output += "    else\n";
    output += "        return \"Success\";\n";
    output += "}\n";
    output += "catch (Exception exc)\n"; //catch exceptions
    output += "{\n";
    output += '    MyException.HandleException(DateTime.Now, new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser()).employeeid.ToString(), System.Reflection.MethodBase.GetCurrentMethod().Name, "", exc);\n';
    output += "    return \"Error: \" + exc.Message + \"; \" + exc.StackTrace;\n";
    output += "}\n";
    output += "}\n";
    return output;
}

//builds C# delete function shell given table name and list of fields
//2/11/20 4:00p UPDATED with access restrictions
function BuildDeleteFunction(table, objectname, field, connectionstring) {
    var output = "//" + GetDate();
    output += "\n[WebMethod]\npublic static String Delete" + objectname + "(String " + field + ")";
    output += "{\n";
    output += "MyEmployees.EmployeeObj currentuser = new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser());\n";
    output += "if (!currentuser.Admin)\n";
    output += 'return "Error: INSUFFICIENT PERMISSIONS";\n\n';
    output += "try {\n";
    output += "    string sqlstring = \"" + BuildDeleteQuery(table, field) + "\";\n";
    output += "    SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings[\"" + connectionstring + "\"].ConnectionString);\n";
    output += "    SqlCommand com = new SqlCommand(sqlstring, con);\n";

    output += "    com.Parameters.AddWithValue(\"@" + field + "\", " + field + ");\n";

    output += "    con.Open();\n";
    output += "    int rowsaffected = com.ExecuteNonQuery(); \n";
    output += "    con.Close();\n";
    output += "     if (rowsaffected == 0)\n";
    output += "        return \"Error: no rows deleted\";\n";
    output += "    else\n";
    output += "        return \"Success\";\n";
    output += "}\n";
    output += "catch (Exception exc)\n";
    output += "{\n";
    output += '    MyException.HandleException(DateTime.Now, new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser()).employeeid.ToString(), System.Reflection.MethodBase.GetCurrentMethod().Name, "", exc);\n';
    output += "    return \"Error: \" + exc.Message + \"; \" + exc.StackTrace;\n";
    output += "}\n";
    output += "}\n";
    return output;
}

//5/6/20 9:21a-9:23a
//uses sqlprocess
//builds C# function for executing delete query on a table
function BuildDeleteFunction2(table, objectname, primaryKeyname) {
    var output = "//" + GetDate();
    output += "\n[WebMethod]\npublic static String Delete" + objectname + "(String " + primaryKeyname + ")";
    output += "{\n";
    output += "MyEmployees.EmployeeObj currentuser = new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser());\n";
    output += "if (!currentuser.Admin)\n";
    output += 'return "Error: INSUFFICIENT PERMISSIONS";\n\n';
    output += "try {\n";
    output += "    MySQL.SqlProcess sql = new MySQL.SqlProcess();\n";
    output += "    sql.setQuery(\"" + BuildDeleteQuery(table, primaryKeyname) + "\");\n"; //build deletion query
    output += "    sql.AddParam(\"@" + primaryKeyname + "\", " + primaryKeyname + ",false,false);\n"; //only needs pK for deletion query

    output += "    sql.OpenConn();\n";
    output += "    int rowsaffected = sql.Execute_CountRows(); \n"; //execute using Sqlprocess object
    output += "    sql.CloseConn();\n";
    output += "     if (rowsaffected == 0)\n";
    output += "        return \"Error: no rows deleted\";\n";
    output += "    else\n";
    output += "        return \"Success\";\n";
    output += "}\n";
    output += "catch (Exception exc)\n"; //handle exceptions
    output += "{\n";
    output += '    MyException.HandleException(DateTime.Now, new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser()).employeeid.ToString(), System.Reflection.MethodBase.GetCurrentMethod().Name, "", exc);\n';
    output += "    return \"Error: \" + exc.Message + \"; \" + exc.StackTrace;\n";
    output += "}\n";
    output += "}\n";
    return output;
}

//9/7/18
function BuildBuildTableFunction(table, fields) {
    var output = "//" + GetDate();
    output += "\n[WebMethod]\npublic static String BuildTable_" + table + "() \n";
    output += "{\n";
    output += "     List<List<String>> " + table + " = Get" + table + "();\n";
    output += "     if (" + table + ".Count==0)\n";
    output += "         return \"--None--\";\n";
    output += "     else if (" + table + ".Count==1 && " + table + "[0].Count==2)\n";
    output += "         return \"Error: \" + " + table + "[0][0] + \"; \" + " + table + "[0][1];\n";
    output += "     else {\n";
    output += "         String output = \"\";\n";
    output += "         output += \"<table class='BasicTable'>\";\n";

    output += "         output += \"<thead><tr>\";\n";
    for (var i = 0; i < fields.length; i++) //skip the ID field
        output += "         output += \"<th>" + fields[i] + "</th>\"; //" + i + ": " + fields[i] + "\n";
    output += "         output += \"</tr></thead>\";\n";

    output += "         output += \"<tbody>\";\n";
    output += "         for (int i = 0; i < " + table + ".Count; i++){\n";
    output += "         output += \"<tr>\";\n";
    for (var i = 0; i < fields.length; i++) //skip the ID field
        output += "         output += \"<td>\"+" + table + "[i][" + i + "]+\"</td>\"; //" + i + ": " + fields[i] + "\n";
    output += "         output += \"</tr>\";\n";
    output += "         }\n";
    output += "         output += \"</tbody>\";\n";

    output += "         output += \"</table>\";\n";
    // output += "         output += \"\";\n";
    //output += "         \n";
    output += "         return output;\n";
    output += "     }\n";
    output += "}\n";
    return output;
}

//11/12/18 12:43p
//builds C# code to process data from table into container object and turn that into an html table for display
function BuildBuildObjectTableFunction(objectname, pluralizedobjectname, containerName, fields, fieldcustomizations) {
    var output = "//" + GetDate() + "\n//function to build html table of " + objectname + " records ";

    var inputparams = AppendToListItems(fields, "String ", "", ", ",true,true);
    var inputparams2 = AppendToListItems(fields, "", "", ", ",true,true);

    output += "\n[WebMethod]\npublic static String BuildTable_" + pluralizedobjectname + "(" + inputparams + ") \n";
    output += "{\n";
    output += "     " + containerName + " all = Get" + pluralizedobjectname + "(" + inputparams2 + ");\n"; //retrieve data using container and GetData func
    output += "     if (all.exc != null)\n"; //check if execution error occured
    output += "         return \"Error: \" + all.exc.Message + \"; \" + all.exc.StackTrace;\n";
    output += "     else if (all.items.Count == 0)\n"; //check if empty dataset
    output += "         return \"--None--\";\n";
    output += "     else {\n";
    output += "         String output = \"\";\n";
    output += "         output += \"<table class='BasicTable'>\";\n"; //build data into html table

    output += "         output += \"<thead><tr>\";\n";
    for (var i = 0; i < fields.length; i++) //skip the ID field
        output += "         output += \"<th>" + $.trim(fields[i]) + "</th>\"; \n"; //build header row
    output += "         output += \"</tr></thead>\";\n";

    output += "         output += \"<tbody>\";\n";
    output += "         for (int i = 0; i < all.items.Count; i++){\n";
    output += "         output += \"<tr>\";\n";
    for (var i = 0; i < fields.length; i++) //skip the ID field
    {
        if (fieldcustomizations[i].datatype=="Bit")
            output += "         output += \"<td>\"+MyForm.ConvertBoolToCheckboxInput(all.items[i]." + $.trim(fields[i]).replace(" ", "") + ")+\"</td>\";\n"; //build data rows
        else
            output += "         output += \"<td>\"+all.items[i]." + $.trim(fields[i]).replace(" ", "") + "+\"</td>\";\n"; //build data rows
    }
    output += "         output += \"</tr>\";\n";
    output += "         }\n";
    output += "         output += \"</tbody>\";\n";

    output += "         output += \"</table>\";\n";
    // output += "         output += \"\";\n";
    //output += "         \n";
    output += "         return output;\n";
    output += "     }\n";
    output += "}\n";
    return output;
}
//10/31/18 12:41p
//2/11/20 4:25p UPDATED to account for variables with spaces in or around them
//builds C# class object for object
function BuildClassObject(objectname, fields, fieldcustomizations) {
    var output = "//" + GetDate();
    output += "\npublic class " + objectname + "\n";
    output += "{" + "\n";

    //VARIABLE DECLARATIONS
    for (var i = 0; i < fields.length; i++) { //add all table fields as object fields
        if (fieldcustomizations[i].datatype == "Bit")
            output += "    public bool " + $.trim(fields[i]).replace(" ", "") + " { get; set; }" + "\n";
        else
            output += "    public String " + $.trim(fields[i]).replace(" ", "") + " { get; set; }" + "\n";
    }
    output += "    public Exception exc { get; set; }" + "\n";

    // CONSTRUCTOR - EMPTY
    output += "    public " + objectname + "()" + "\n";
    output += "    {" + "\n";
    for (var i = 0; i < fields.length; i++) {
        if (fieldcustomizations[i].datatype == "Bit")
            output += "    " + $.trim(fields[i]).replace(" ", "") + "  = " + fieldcustomizations[i].BitDefault + ";" + "\n";
        else 
            output += "    " + $.trim(fields[i]).replace(" ", "") + "  = \"\";" + "\n";
    }
    output += "    }" + "\n";

    //CONSTRUCTOR - FULL
    output += "    public " + objectname + "(";
    for (var i = 0; i < fields.length; i++) {
        output += "String " + $.trim(fields[i]).replace(" ", "") + ", ";
    output = output.substring(0, output.length - 2);//remove final comma
    output += ") " + "\n";
    output += "    {" + "\n";
    for (var i = 0; i < fields.length; i++) {
        if (fieldcustomizations[i].datatype == "Bit")
            output += "    this." + $.trim(fields[i]).replace(" ", "") + "  = MySQL.TryParse_Boolean(" + $.trim(fields[i]).replace(" ", "") + ");" + "\n";
        else
            output += "    this." + $.trim(fields[i]).replace(" ", "") + "  = " + $.trim(fields[i]).replace(" ", "") + ";" + "\n";
    }
    output += "    }" + "\n";

    //CONSTRUCTOR - EXCEPTION
    output += "    public " + objectname + "(Exception exc)" + "\n";
    output += "    {" + "\n";
    output += "    this.exc = exc;" + "\n";
    output += "    }" + "\n";
    

    output += "}" + "\n";
    return output;
}

//11/12/18 12:29p
//builds C# class object container for objects
function BuildClassObjectContainer(objectname, containerName, primaryKeyname) {
    //var classname = pluralizedobjectname + "Container";
    var output = "//" + GetDate();
    output += "\npublic class " + containerName + "\n";
    output += "{" + "\n";

    //VARIABLE DECLARATIONS
    output += "    public List<" + objectname + "> items { get; set; }" + "\n"; //container holds list of objects
    output += "    public Exception exc { get; set; }" + "\n";

    // CONSTRUCTOR - EMPTY
    output += "    public " + containerName + "()" + "\n";
    output += "    {" + "\n";
    output += "    items = new List<" + objectname + ">();\n";
    output += "    }" + "\n";

    //CONSTRUCTOR - EXCEPTION
    output += "    public " + containerName + "(Exception exc)" + "\n";
    output += "    {" + "\n";
    output += "    this.exc = exc;" + "\n";
    output += "    }" + "\n";

    //TOLIST 5/6/20 9:33a-9:36a
    output += "    public List<List<String>> ToList()\n";
    output += "    {" + "\n";
    output += "    if (exc != null || items.Count == 0)\n";
    output += "         return new List<List<string>>();\n";
    output += "    List<List<String>> output = new List<List<string>>();\n";
    output += "    foreach (" + objectname + " item in items)\n";
    output += "         output.Add(new List<string> { item." + primaryKeyname + ", item.DESCRIPTION });\n";
    output += "    return output;\n";
    output += "    }" + "\n";

    output += "}" + "\n";
    return output;
}

//9/30/19 10:34a-11:11a
//build C# function that generates EditForm
//assumes fields[0] is primary key
//NOT USED
function BuildBuildEditFormFunction(objectname, tablename, fields) {
    var output = "//" + GetDate();
    output += "\n[WebMethod]\npublic static String BuildForm_Edit" + objectname + "(String " + fields[0] + ") \n";
    output += "{\n";
    output += "     MyEmployees.EmployeeObj currentuser = new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser());\n";
    output += "     if (!currentuser.Admin)\n";
    output += "         return \"Error: INSUFFICIENT PERMISSIONS\";\n";
    output += "     else\n";
    output += "     {\n";

    var inputparams2 = AppendToListItems(fields, "", "", ", ");

    output += "     " + tablename + "Container all = Get" + tablename + "(" + fields[0] + ");\n";

    output += "     if (all.exc != null)\n";
    output += "         return \"Error: \" + all.exc.Message + \"; \" + all.exc.StackTrace;\n";
    output += "     else if (all.items.Count == 0)\n";
    output += "         return \"Error: unrecognized " + fields[0] + "\";\n";
    output += "     else if (all.items.Count > 1)\n";
    output += "         return \"Error: multiple records found under this " + fields[0] + "\";\n";
    output += "     else {\n";
    output += "         " + objectname + " item = all.items[0];\n";
    output += "         String output = \"\";\n";
    output += "         output += \"<table class='BasicTable'>\";\n";
    output += "         output += \"<thead><tr>\";\n";
    for (var i = 1; i < fields.length; i++) //skip the ID field
        output += '         output += \"        <th>' + fields[i] + ': </th><td><input type=\'text\' value=\'\" + item.' + fields[i] + ' + \"\' id=\'Edit' + objectname + '_' + fields[i] + 'Input\" + item.' + fields[0] + ' + \"\'/></td>\"; \n';
    output += "         output += \"</tr></thead>\";\n";
    output += "         output += \"<tbody>\";\n";

    output += '         output += \"<input type=\'button\' value=\'Save Changes\' onclick=\\"Edit' + objectname + '_Submit(\'\" + item.' + fields[0] + ' + \"\')\\" />\";\n';
    output += "         return output;\n";
    output += "     }\n";

    output += "     }\n";

    output += "}\n";
    return output;
}

//10/18/19 11:11a-11:30a
//build C# function that generates AddEditForm
//assumes fields[0] is primary key
function BuildBuildAddEditFormFunction(objectname, pluralizedobjectname, containerName, tablename, fields) {
    var output = "//" + GetDate2() + "\n//build the form to either add or edit a " + objectname + " record";
    output += "\n[WebMethod]\npublic static String BuildForm_AddEdit" + objectname + "(String " + fields[0] + ") \n";
    output += "{\n";
    output += "     MyEmployees.EmployeeObj currentuser = new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser());\n";
    output += "     if (!currentuser.Admin)\n";
    output += "         return \"Error: INSUFFICIENT PERMISSIONS\";\n"; //where applicable, restrict access to admin only
    //output += "     else\n";
    //output += "     {\n";
    output += 'bool doNew = (' + fields[0] + ' == "");\n'; //determine if insert/update query based on whether or not pk has value
    output += objectname + " item = new " + objectname + "();\n";
    output += "if(!doNew)\n";
    output += "{\n";
    var filler = "";
    for (var i = 1; i < fields.length; i++)
        filler += ', ""';
    //filler = filler.substring(0, filler.length - 2);
    output += containerName + " all = Get" + pluralizedobjectname + "(" + fields[0] + filler + ");\n"; //if running update, need to get existing data and fill form with current record info
    output += "if (all.exc != null)\n";
    output += "     return \"Error: \" + all.exc.Message + \"; \" + all.exc.StackTrace;\n";
    output += " else if (all.items.Count == 0)\n";
    output += "     return \"Error: unrecognized ID\";\n";
    output += " else if (all.items.Count > 1)\n";
    output += "     return \"Error: multiple records found under this ID\";\n";
    output += " item = all.items[0];\n";
    output += "}\n";
    output += "String output = (doNew) ? \"<h3>Add " + objectname + "</h3>\" : \"<h3>Edit " + objectname + " #\" + item." + fields[0] + "  + \"</h3>\";\n";
    //output += "     String output = \"\";\n";
    output += "         output += \"<table class='BasicTable'>\";\n";
    output += "         output += \"<thead><tr>\";\n";
    //output += "     if(" + fields[0] + " != null) //if an ID HAS been passed in, this form will be used to EDIT record \n";
    //output += "     {\n";
    //output += "     output += \"<h3>Edit " + objectname + "</h3>\";\n";
    //var inputparams2 = AppendToListItems(fields, "", "", ", ");

    //output += "     " + tablename + "Container all = Get" + tablename + "(" + fields[0] + ");\n";

    //output += "     if (all.exc != null)\n";
    //output += "         return \"Error: \" + all.exc.Message + \"; \" + all.exc.StackTrace;\n";
    //output += "     else if (all.items.Count == 0)\n";
    //output += "         return \"Error: unrecognized " + fields[0] + "\";\n";
    //output += "     else if (all.items.Count > 1)\n";
    //output += "         return \"Error: multiple records found under this " + fields[0] + "\";\n";
    //output += "     else {\n";
    //output += "         " + objectname + " item = all.items[0];\n";
    //output += "         String output = \"\";\n";
    for (var i = 1; i < fields.length; i++) //skip the ID field
    {
        if (fieldcustomizations[i].isEditable) {
            if (fieldcustomizations[i].datatype == "Bit") { //todo: check verification?
                output += '         output += \"        <th>' + $.trim(fields[i]) + ': </th><td><input type=\'checkbox\' value=\'\" + item.' + $.trim(fields[i]).replace(" ", "") + ' + \"\' id=\'AddEdit' + objectname + '_' + $.trim(fields[i]).replace(" ", "") + 'Input\" + item.' + fields[0] + ' + \"\'/></td>\"; \n';
            }
            else if (fieldcustomizations[i].datatype == "Number") { //todo: check verification?
                output += '         output += \"        <th>' + $.trim(fields[i]) + ': </th><td><input min="' + fieldcustomizations[i].Min + '" max="' + fieldcustomizations[i].Max + '" step="' + fieldcustomizations[i].Step + '" type=\'number\' value=\'\" + item.' + $.trim(fields[i]).replace(" ", "") + ' + \"\' id=\'AddEdit' + objectname + '_' + $.trim(fields[i]).replace(" ", "") + 'Input\" + item.' + fields[0] + ' + \"\'/></td>\"; \n';
            }
            else if (fieldcustomizations[i].datatype == "Date") { //todo: check verification?
                output += '         output += \"        <th>' + $.trim(fields[i]) + ': </th><td><input type=\'date\' value=\'\" + item.' + $.trim(fields[i]).replace(" ", "") + ' + \"\' id=\'AddEdit' + objectname + '_' + $.trim(fields[i]).replace(" ", "") + 'Input\" + item.' + fields[0] + ' + \"\'/></td>\"; \n';
            }
            else if (fieldcustomizations[i].datatype == "DateTime") { //todo: check verification?
                output += '         output += \"        <th>' + $.trim(fields[i]) + ': </th><td><input type=\'datetime-local\' value=\'\" + item.' + $.trim(fields[i]).replace(" ", "") + ' + \"\' id=\'AddEdit' + objectname + '_' + $.trim(fields[i]).replace(" ", "") + 'Input\" + item.' + fields[0] + ' + \"\'/></td>\"; \n';
            }
            else
                output += '         output += \"        <th>' + $.trim(fields[i]) + ': </th><td><input type=\'text\' value=\'\" + item.' + $.trim(fields[i]).replace(" ", "") + ' + \"\' id=\'AddEdit' + objectname + '_' + $.trim(fields[i]).replace(" ", "") + 'Input\" + item.' + fields[0] + ' + \"\'/></td>\"; \n';
        }
       
    }
//output += "     } }\n";

   // output += "     else { //if an ID has NOT been passed in, this form will be used to ADD a record \n";
   //// output += "         String output = \"\";\n";
   // output += "     output += \"<h3>Add " + objectname + "</h3>\";\n";
   // for (var i = 1; i < fields.length; i++) //skip the ID field
   //     output += '         output += \"        <th>' + fields[i] + ': </th><td><input type=\'text\' value=\'\' id=\'AddEdit' + objectname + '_' + fields[i] + 'Input\'/></td>\"; \n';
   // output += "     }\n";

    output += "         output += \"</tr></thead>\";\n";
    output += "         output += \"</table>\";\n";
    output += "         String buttontext = (" + fields[0] + " == \"\") ? \"Add " + objectname + "\" : \"Save Changes\";\n";
    output += '         output += \"<input type=\'button\' value=\'" + buttontext + "\' onclick=\\"AddEdit' + objectname + '_Submit(\'" +' + fields[0] + '+ "\')\\" />\";\n';
    output += "         return output;\n";

    //output += "     }\n";

    output += "}\n";
    return output;
}

//10/18/19 11:30a-11:33a
function BuildJSAddEditSubmitFunction(table, codepage, fields) {
    var output = "//" + GetDate() + "\n";
    output += "function AddEdit" + table + "_Submit(" + fields[0] + ") {\n";
    output += "var obj = {};\n";
    output += "obj." + fields[0] + " = " + fields[0] + ";\n";
    for (var i = 1; i < fields.length; i++)
        output += "obj." + fields[i] + " = $(\"#AddEdit" + table + "_" + fields[i] + "Input\" + " + fields[0] + ").val();\n";
    output += "console.log(\"AddEdit" + table + "_Submit() obj: \", obj);\n";
    
    output += "$.ajax({\n";
    output += "     type: \"POST\",\n";
    output += "    url: \"" + codepage + ".aspx/AddEdit" + table + "\",\n";
    output += "    data: JSON.stringify(obj), \n";
    output += "    contentType: \"application/json; charset=utf-8\",\n";
    output += "     success: function (data) {\n";
    output += "       console.log(\"AddEdit" + table + "_Submit() preliminary success: \", data);\n";
    output += "         if (data.d == \"Success\") {\n";
    output += "           console.log(\"AddEdit" + table + "_Submit() success: \", data);\n";
    output += "           Update" + table + "Table();\n";
    output += "       }\n";
    output += "       else {\n";
    output += "           alert(\"AddEdit" + table + "_Submit() failed: \" + data.d); \n";
    output += "           console.log(\"AddEdit" + table + "_Submit() failed: \" + data.d); \n";
    output += "       }\n";
    output += "   }, \n";
    output += "   error: function (msg) {\n";
    output += "       alert(\"New" + table + "_Submit() AJAX Failure: \" + msg.statusText);\n";
    output += "       console.log(\"New" + table + "_Submit() AJAX Failure: \" + msg.responseText);\n";
    output += "   },\n";
    output += "   dataType: \"json\",\n";
    output += "    async: true\n";
    output += "}); \n";
    output += "}\n";
    return output;
}

//10/18/19 11:34a-11:40a
function BuildAddEditFunction(table, objectname, connectionstring, fields) {
    var output = "//" + GetDate();
    output += "\n[WebMethod]\npublic static String AddEdit" + objectname + "(";
    for (var i = 0; i < fields.length; i++)
        output += "String " + fields[i] + ",";
    output = output.substring(0, output.length - 1);
    output += ") \n";
    output += "{\n";
    output += "try {\n";
    output += "    string sqlstring = (" + fields[0] + " == null ) ? \"" + BuildInsertQuery(table,fields) + "\" : \"" + BuildUpdateQuery(table, fields) + "\" ; //if no ID passed in, CREATE record. if ID WAS passed in, UPDATE record \n";
    output += "    SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings[\"" + connectionstring + "\"].ConnectionString);\n";
    output += "    SqlCommand com = new SqlCommand(sqlstring, con);\n";

    output += " if (" + fields[0] + " != null ) //only include ID if we're running an update query \n";
    output += "    com.Parameters.AddWithValue(\"@" + fields[0] + "\", " + fields[0] + ");\n";
    for (var i = 1; i < fields.length; i++)
        output += "    com.Parameters.AddWithValue(\"@" + fields[i] + "\", " + fields[i] + ");\n";

    output += "    con.Open();\n";
    output += "    int rowsaffected = com.ExecuteNonQuery(); \n";
    output += "    con.Close();\n";
    output += "     if (rowsaffected == 0)\n";
    output += "        return \"Error: no rows changed\";\n";
    output += "    else\n";
    output += "        return \"Success\";\n";
    output += "}\n";
    output += "catch (Exception exc)\n";
    output += "{\n";
    output += "    MyException.HandleException(DateTime.Now, new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser()).employeeid.ToString(), System.Reflection.MethodBase.GetCurrentMethod().Name, \"\", exc);\n";
    output += "    return \"Error: \" + exc.Message + \"; \" + exc.StackTrace;\n";
    output += "}\n";
    output += "}\n";
    return output;
}


//11/5/18 1:25p
function BuildJSAddFunction(table, codepage, fields) {
    var output = "//" + GetDate() + "\n";
    output += "function New" + table + "_Submit() {\n";
    output += "var obj = {};\n";
    for (var i = 0; i < fields.length; i++)
        output += "obj." + fields[i] + " = $(\"#New" + table + "_" + fields[i] + "Input\").val();\n";
    output += "console.log(\"New" + table + "_Submit() obj: \", obj);";


    output += "$.ajax({\n";
    output += "     type: \"POST\",\n";
    output += "    url: \"" + codepage + ".aspx/Add" + table + "\",\n";
    output += "    data: JSON.stringify(obj), \n";
    output += "    contentType: \"application/json; charset=utf-8\",\n";
    output += "     success: function (data) {\n";
    output += "       console.log(\"New" + table + "_Submit() preliminary success: \", data);\n";
    output += "         if (data.d == \"Success\") {\n";
    output += "           console.log(\"New" + table + "_Submit() success: \", data);\n";
    output += "           Update" + table + "Table();\n";
    output += "       }\n";
    output += "       else {\n";
    output += "           alert(\"New" + table + "_Submit() failed: \" + data.d); \n";
    output += "       }\n";
    output += "   }, \n";
    output += "   error: function (msg) {\n";
    output += "       alert(\"New" + table + "_Submit() AJAX Failure: \" + msg.statusText);\n";
    output += "       console.log(msg); \n";
    output += "   },\n";
    output += "   dataType: \"json\",\n";
    output += "    async: false\n";
    output += "}); \n";
    output += "}\n";
    return output;
}

function BuildJSUpdateTableFunction(table, codepage) {
    var output = "//" + GetDate()+"\n";
    output += "function Update" + table + "Table() {\n";
    output += "$.ajax({\n";
    output += "     type: \"POST\",\n";
    output += "    url: \"" + codepage + ".aspx/BuildTable_" + table + "\",\n";
    output += "    contentType: \"application/json; charset=utf-8\",\n";
    output += "success: function (data) {\n";
    output += "    console.log(\"Update" + table + "Table() success: \", data);\n";
    output += "    $(\"#" + table + "Div\").replaceWith(data.d);\n";
    output += "},\n";
    output += "   error: function (msg) {\n";
    output += "       alert(\"Update" + table + "Table() AJAX Failure: \" + msg.statusText);\n";
    output += "       console.log(msg); \n";
    output += "   },\n";
    output += "   dataType: \"json\",\n";
    output += "    async: false\n";
    output += "}); \n";
    output += "}\n";
    return output;
}

//2/12/20 9:23a-9:30a
//builds JS function that updates front end html table of data via ajax
function BuildJSUpdateTableFunction2(objectname, pluralizedobjectname, codepage, fields) {
    var output = "//" + GetDate() + "\n";
    var functionName = "Update" + pluralizedobjectname + "Table";
    output += "function " + functionName + "() {\n";

    output += "var obj={};\n";
    output += "//obj." + fields[0] + " = " + fields[0] + ";\n";
    for (var i = 1; i < fields.length; i++)
        output += "//obj." + $.trim(fields[i]).replace(" ", "") + " = " + $.trim(fields[i]).replace(" ", "") + ";\n";

    output += 'UpdateElement2("' + functionName + '()", "#' + objectname + 'sDiv", obj, "' + codepage + '.aspx/BuildTable_' + pluralizedobjectname + '")\n'; //, null, true, "", "", true, null, null

    //output += "$.ajax({\n";
    //output += "     type: \"POST\",\n";
    //output += "    url: \"" + codepage + ".aspx/BuildTable_" + table + "\",\n";
    //output += "    contentType: \"application/json; charset=utf-8\",\n";
    //output += "success: function (data) {\n";
    //output += "    console.log(\"" + functionName + "() success: \", data);\n";
    //output += "    $(\"#" + objectname + "sDiv\").replaceWith(data.d);\n";
    //output += "},\n";
    //output += "   error: function (msg) {\n";
    //output += "       alert(\"" + functionName + "() AJAX Failure: \" + msg.statusText);\n";
    //output += "       console.log(\"" + functionName + "() AJAX Failure: \" + msg.responseText);\n";
    //output += "   },\n";
    //output += "   dataType: \"json\",\n";
    //output += "    async: false\n";
    //output += "}); \n";
    output += "}\n";
    return output;
}

//9/30/19 10:16a-10:24a
//assumes fields[0] is primary key
//2/12/20 9:13a UPDATED to be AddEdit submit rather than an Update submit
function BuildJSAddEditSubmitFunctions(objectname, codepage, fields) {
    var output = "//" + GetDate() + "\n";
    output += "function AddEdit" + objectname + "_Submit(" + fields[0] + ") {\n";
    //output += "if (" + fields[0] + "==null || " + fields[0] + "=='')\n";
    //output += "alert('Missing " + fields[0] + "');\n";
    //output += "else {\n";
   // output += "console.log('Update" + objectname + "_Submit(): ' + " + fields[0] + ");\n";
    output += "var obj={};\n";
    output += "obj." + fields[0] + " = " + fields[0] + ";\n";
    for (var i = 1; i < fields.length; i++)
        output += "obj." + $.trim(fields[i]).replace(" ", "") + " = $(\"#AddEdit" + objectname + "_" + $.trim(fields[i]).replace(" ","") + "Input\" + " + fields[0] + ").val();\n";
    output += "console.log(\"AddEdit" + objectname + "_Submit() obj: \", obj);";
    
    output += "$.ajax({\n";
    output += "     type: \"POST\",\n";
    output += "    url: \"" + codepage + ".aspx/AddEdit" + objectname + "\",\n";
    output += "    data: JSON.stringify(obj), \n";
    output += "    contentType: \"application/json; charset=utf-8\",\n";
    output += "     success: function (data) {\n";
    output += "       console.log(\"AddEdit" + objectname + "_Submit() preliminary success: \", data);\n";
    output += "         if (data.d == \"Success\") {\n";
    output += "           console.log(\"AddEdit" + objectname + "_Submit() success: \", data);\n";
    output += "           Update" + objectname + "Table();\n";
    output += "       }\n";
    output += "       else {\n";
    output += "           alert(\"AddEdit" + objectname + "_Submit() failed: \" + data.d); \n";
    output += "           console.log(\"AddEdit" + objectname + "_Submit() failed: \" + data.d); \n";
    output += "       }\n";
    output += "   }, \n";
    output += "   error: function (msg) {\n";
    output += "       alert(\"AddEdit" + objectname + "_Submit() AJAX Failure: \" + msg.statusText);\n";
    output += "       console.log(\"AddEdit" + objectname + "_Submit() AJAX Failure: \" + msg.responseText);\n";
    output += "   },\n";
    output += "   dataType: \"json\",\n";
    output += "    async: false\n";
    output += "}); \n";
    output += "}\n";
    return output;
}

//2/12/20 9:38a-9:41a
//uses RunFunction
//builds JS function that executes add/edit operation on table data via ajax
function BuildJSAddEditSubmitFunction2(objectname, pluralizedobjectname, codepage, fields) {
    var output = "//" + GetDate() + "\n//submit add/edit record using RunFunction\n";
    output += "function AddEdit" + objectname + "_Submit(" + fields[0] + ") {\n";
    //output += "if (" + fields[0] + "==null || " + fields[0] + "=='')\n";
    //output += "alert('Missing " + fields[0] + "');\n";
    //output += "else {\n";
    // output += "console.log('Update" + objectname + "_Submit(): ' + " + fields[0] + ");\n";
    output += "var obj={};\n";
    output += "obj." + fields[0] + " = " + fields[0] + ";\n";
    for (var i = 1; i < fields.length; i++) {
        if (fieldcustomizations[i].isEditable) {
            if (fieldcustomizations[i].datatype == "Bit")
                output += "obj." + $.trim(fields[i]).replace(" ", "") + " = $(\"#AddEdit" + objectname + "_" + $.trim(fields[i]).replace(" ", "") + "Input\" + " + fields[0] + ").is(':checked');\n";
            else
                output += "obj." + $.trim(fields[i]).replace(" ", "") + " = $(\"#AddEdit" + objectname + "_" + $.trim(fields[i]).replace(" ", "") + "Input\" + " + fields[0] + ").val();\n";
        }
    }
//output += "console.log(\"AddEdit" + objectname + "_Submit() obj: \", obj);";

    output += 'RunFunction("AddEdit' + objectname + '_Submit()", obj, "' + codepage + '.aspx/AddEdit' + objectname + '", [ "==", "Success"],\n' +
        'function () {\n' +
        'CloseModal("AddEdit' + objectname + 'Form");\n' +
        'Update' + pluralizedobjectname + 'Table();\n' +
        '},null);\n';


    //output += "$.ajax({\n";
    //output += "     type: \"POST\",\n";
    //output += "    url: \"" + codepage + ".aspx/AddEdit" + objectname + "\",\n";
    //output += "    data: JSON.stringify(obj), \n";
    //output += "    contentType: \"application/json; charset=utf-8\",\n";
    //output += "     success: function (data) {\n";
    //output += "       console.log(\"AddEdit" + objectname + "_Submit() preliminary success: \", data);\n";
    //output += "         if (data.d == \"Success\") {\n";
    //output += "           console.log(\"AddEdit" + objectname + "_Submit() success: \", data);\n";
    //output += "           Update" + objectname + "Table();\n";
    //output += "       }\n";
    //output += "       else {\n";
    //output += "           alert(\"AddEdit" + objectname + "_Submit() failed: \" + data.d); \n";
    //output += "           console.log(\"AddEdit" + objectname + "_Submit() failed: \" + data.d); \n";
    //output += "       }\n";
    //output += "   }, \n";
    //output += "   error: function (msg) {\n";
    //output += "       alert(\"AddEdit" + objectname + "_Submit() AJAX Failure: \" + msg.statusText);\n";
    //output += "       console.log(\"AddEdit" + objectname + "_Submit() AJAX Failure: \" + msg.responseText);\n";
    //output += "   },\n";
    //output += "   dataType: \"json\",\n";
    //output += "    async: false\n";
    //output += "}); \n";
    output += "}\n";
    return output;
}

//9/30/19 10:30a-10:33a
//build the function that retrieves the popup/modal edit form
//2/11/20 4:19p UPDATED to use AddEdit naming
function BuildJSShowEditFormFunction(objectname, codepage, primarykey) {
    var output = "//" + GetDate() + "\n";
    output += "function AddEdit" + objectname + "_Show(" + primarykey + ") {\n";
    //output += "if (" + primarykey + "==null || " + primarykey + "=='')\n";
    //output += "alert('Missing " + primarykey + "');\n";
    //output += "else {\n";
    // output += "console.log('Update" + objectname + "_Submit(): ' + " + fields[0] + ");\n";
    output += "var obj={};\n";
    output += "obj." + primarykey + " = " + primarykey + ";\n";
    output += "console.log(\"AddEdit" + objectname + "_Show() obj: \", obj);";

    output += "$.ajax({\n";
    output += "     type: \"POST\",\n";
    output += "    url: \"" + codepage + ".aspx/BuildForm_AddEdit" + objectname + "\",\n";
    output += "    data: JSON.stringify(obj), \n";
    output += "    contentType: \"application/json; charset=utf-8\",\n";
    output += "     success: function (data) {\n";
    output += "       console.log(\"AddEdit" + objectname + "_Show() success: \", data);\n";
    output += "       CreateModal('AddEdit" + objectname + "Form', data.d, true, true, null);\n";
    output += "   }, \n";
    output += "   error: function (msg) {\n";
    output += "       alert(\"AddEdit" + objectname + "_Show() AJAX Failure: \" + msg.statusText);\n";
    output += "       console.log(\"AddEdit" + objectname + "_Show() AJAX Failure: \" + msg.responseText);\n";
    output += "   },\n";
    output += "   dataType: \"json\",\n";
    output += "    async: false\n";
    output += "}); \n";
   // output += "}\n";
    output += "}\n";
    return output;
}

//2/12/20 9:33a-9:36a
//builds JS function that generates and displays add/edit form for add/edit operation on table data via ajax
function BuildJSShowAddEditFormFunction(objectname, codepage, primarykey) {
    var output = "//" + GetDate() + "\n//create popup add/edit form\n";
    output += "function AddEdit" + objectname + "_Show(" + primarykey + ") {\n";
    //output += "if (" + primarykey + "==null || " + primarykey + "=='')\n";
    //output += "alert('Missing " + primarykey + "');\n";
    //output += "else {\n";
    // output += "console.log('Update" + objectname + "_Submit(): ' + " + fields[0] + ");\n";
    output += "var obj={};\n";
    output += "obj." + primarykey + " = " + primarykey + ";\n";
    //output += "console.log(\"AddEdit" + objectname + "_Show() obj: \", obj);";

    output += 'RunModal("AddEdit' + objectname + '_Show()", "AddEdit' + objectname + 'Form", obj, "' + codepage + '.aspx/BuildForm_AddEdit' + objectname + '", null, null, null, null, null, true, true, null);\n';

    //output += "$.ajax({\n";
    //output += "     type: \"POST\",\n";
    //output += "    url: \"" + codepage + ".aspx/BuildForm_AddEdit" + objectname + "\",\n";
    //output += "    data: JSON.stringify(obj), \n";
    //output += "    contentType: \"application/json; charset=utf-8\",\n";
    //output += "     success: function (data) {\n";
    //output += "       console.log(\"AddEdit" + objectname + "_Show() success: \", data);\n";
    //output += "       CreateModal('AddEdit" + objectname + "Form', data.d, true, true, null);\n";
    //output += "   }, \n";
    //output += "   error: function (msg) {\n";
    //output += "       alert(\"AddEdit" + objectname + "_Show() AJAX Failure: \" + msg.statusText);\n";
    //output += "       console.log(\"AddEdit" + objectname + "_Show() AJAX Failure: \" + msg.responseText);\n";
    //output += "   },\n";
    //output += "   dataType: \"json\",\n";
    //output += "    async: false\n";
    //output += "}); \n";
    // output += "}\n";
    output += "}\n";
    return output;
}

//11/12/18 12:28p
function BuildSelectObjFunction(table, objectname, fields, connectionstring) {
    var output = "//" + GetDate();

    var inputparams = AppendToListItems(fields, "String ", "", ", ",true,true);
    var conditionals = AppendToListItems(fields, "", ' != ""', " || ",true,true);

    output += "\npublic static " + objectname + "Container Get" + objectname + "s(" + inputparams + ") \n";
    output += "{\n";
    output += "try {\n";
    output += "String sqlstring = \"" + BuildSelectQuery(table, fields) + "\";\n";

    output += "if (" + conditionals + ") //if at least one of these isnt blank\n";
    output += "{";
    output += 'sqlstring += " WHERE ";\n';
    for (var i = 0; i < fields.length; i++) {
        output += 'if (' + $.trim(fields[i]).replace(" ","") + ' != "")\n';
        if ($.trim(fields[i]).indexOf(" ")!=-1)
            output += 'sqlstring += " [' + $.trim(fields[i]) + '] = @' + $.trim(fields[i]).replace(" ", "") + ' AND ";\n';
        else
            output += 'sqlstring += " ' + $.trim(fields[i]) + ' = @' + $.trim(fields[i]).replace(" ", "") + ' AND ";\n';
    }
    output += "sqlstring = sqlstring.Substring(0, sqlstring.Length - 4);";
    output += "}";

    output += "System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings[\"" + connectionstring + "\"].ToString());\n";
    output += "System.Data.SqlClient.SqlCommand comm = new System.Data.SqlClient.SqlCommand(sqlstring, con);\n";
    for (var i = 0; i < fields.length; i++) {
        output += 'if (' + $.trim(fields[i]).replace(" ", "") + ' != "")\n';
        output += 'comm.Parameters.AddWithValue("@' + $.trim(fields[i]).replace(" ", "") + '", ' + $.trim(fields[i]).replace(" ", "") + ');\n';
    }
    output += "System.Data.SqlClient.SqlDataReader reader;\n";
    output += table + "Container output = new " + objectname + "Container();\n";
    output += "con.Open();\n";
    output += "reader = comm.ExecuteReader();\n";
    output += "while (reader.Read())\n";
    output += "{\n";
    output += "output.items.Add(new " + objectname + "(";
    for (var i = 0; i < fields.length; i++)
        output += "reader[\"" + $.trim(fields[i]) + "\"].ToString(), ";
    output = output.slice(0, -2); //remove the last ", "
    output += "));\n";
    output += "}\n";
    output += "con.Close(); \n";
    output += "return output; \n";
    output += "}\n";
    output += "catch (Exception exc)";
    output += "{\n";
    output += '    MyException.HandleException(DateTime.Now, new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser()).employeeid.ToString(), System.Reflection.MethodBase.GetCurrentMethod().Name, "", exc);\n';
    output += "    return new " + objectname + "Container(exc);\n";
    output += "}\n";
    output += "}\n";
    return output;
}

//5/28/20 11:43a-11:48a
//uses updated SqlProcess object
//builds C# function to retrieve data fromt able and process it into container object
function BuildSelectObjFunction3(table, objectname, pluralizedobjectname, containerName, fields) {
    var output = "//" + GetDate();

    var inputparams = AppendToListItems(fields, "String ", "", ", ", true, true);
    var conditionals = AppendToListItems(fields, "", ' != ""', " || ", true, true);

    output += "\npublic static " + containerName + " Get" + pluralizedobjectname + "(" + inputparams + ") \n";
    output += "{\n";
    output += "try {\n";
    if (view == undefined || view == null || view=="")
        output += "String sqlstring = \"" + BuildSelectQuery(table, fields) + "\";\n"; //build select query using tablename as datasource
    else
        output += "String sqlstring = \"" + BuildSelectQuery(view, fields) + "\";\n"; //build select query using view as datasource
    output += "MySQL.SqlProcess sql = new MySQL.SqlProcess();\n";
    output += "sql.setQuery(sqlstring);\n";
    
    for (var i = 0; i < fields.length; i++) {
        var fieldName = $.trim(fields[i]).replace(" ", "");
        output += "sql.AddConditional(\"" + fieldName + "\"," + fieldName + "); \n"; //use all fields as search params for query if not empty value
    }
    output += containerName + " output = new " + containerName + "();\n";
    output += "sql.OpenConn();\n";
    output += "SqlDataReader reader = sql.Execute_Read();\n"; //execute read query
    output += "while (reader.Read())\n";
    output += "{\n";
    output += "output.items.Add(new " + objectname + "("; //add each row to container as object, processing in each field from read()
    for (var i = 0; i < fields.length; i++)
        output += "reader[\"" + $.trim(fields[i]) + "\"].ToString(), ";
    output = output.slice(0, -2); //remove the last ", "
    output += "));\n";
    output += "}\n";
    output += "sql.CloseConn(); \n";
    output += "return output; \n";
    output += "}\n";
    output += "catch (Exception exc)"; //handle exceptions
    output += "{\n";
    output += '    MyException.HandleException(DateTime.Now, new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser()).employeeid.ToString(), System.Reflection.MethodBase.GetCurrentMethod().Name, "", exc);\n';
    output += "    return new " + containerName + "(exc);\n";
    output += "}\n";
    output += "}\n";
    return output;
}

//5/6/20 9:24a-9:27a
//uses sqlprocess
function BuildSelectObjFunction2(table, objectname, fields) {
    var output = "//" + GetDate();

    var inputparams = AppendToListItems(fields, "String ", "", ", ", true, true);
    var conditionals = AppendToListItems(fields, "", ' != ""', " || ", true, true);

    output += "\npublic static " + objectname + "Container Get" + objectname + "s(" + inputparams + ") \n";
    output += "{\n";
    output += "try {\n";
    output += "String sqlstring = \"" + BuildSelectQuery(table, fields) + "\";\n";

    output += "if (" + conditionals + ") //if at least one of these isnt blank\n";
    output += "{";
    output += 'sqlstring += " WHERE ";\n';
    for (var i = 0; i < fields.length; i++) {
        output += 'if (' + $.trim(fields[i]).replace(" ", "") + ' != "")\n';
        if ($.trim(fields[i]).indexOf(" ") != -1)
            output += 'sqlstring += " [' + $.trim(fields[i]) + '] = @' + $.trim(fields[i]).replace(" ", "") + ' AND ";\n';
        else
            output += 'sqlstring += " ' + $.trim(fields[i]) + ' = @' + $.trim(fields[i]).replace(" ", "") + ' AND ";\n';
    }
    output += "sqlstring = sqlstring.Substring(0, sqlstring.Length - 4);\n";
    output += "}\n";

    output += "MySQL.SqlProcess sql = new MySQL.SqlProcess();\n";
    output += "sql.setQuery(sqlstring);\n";
    for (var i = 0; i < fields.length; i++) {
        output += 'sql.AddParam(' + $.trim(fields[i]).replace(" ", "") + ' != "","@' + $.trim(fields[i]).replace(" ", "") + '", ' + $.trim(fields[i]).replace(" ", "") + ');\n';
    }
    output += "sql.OpenConn();\n";
    output += "SqlDataReader reader = sql.Execute_Read();\n";
    output += table + "Container output = new " + objectname + "Container();\n";
    output += "while (reader.Read())\n";
    output += "{\n";
    output += "output.items.Add(new " + objectname + "(";
    for (var i = 0; i < fields.length; i++)
        output += "reader[\"" + $.trim(fields[i]) + "\"].ToString(), ";
    output = output.slice(0, -2); //remove the last ", "
    output += "));\n";
    output += "}\n";
    output += "sql.CloseConn(); \n";
    output += "return output; \n";
    output += "}\n";
    output += "catch (Exception exc)";
    output += "{\n";
    output += '    MyException.HandleException(DateTime.Now, new MyEmployees.EmployeeObj(MyEmployees.GetLoggedInEmpUser()).employeeid.ToString(), System.Reflection.MethodBase.GetCurrentMethod().Name, "", exc);\n';
    output += "    return new " + objectname + "Container(exc);\n";
    output += "}\n";
    output += "}\n";
    return output;
}

//9/26/19 3:08p-3:09p
//2/11/20 4:46p UPDATED with trim and removeWhitespace options
//this function cleans up a list of strings, with options for adding/removing prefixes or suffixes, trimming or removing the whitespace of each value
function AppendToListItems(items, prefix, suffix, suffixToRemove, trim=false,removeWhitespace=false) {
    var output = '';
    for (var i = 0; i < items.length; i++) { //loop through each item in array
        var item = items[i];
        if (trim) //if trim, trim
            item = $.trim(item);
        if (removeWhitespace) //if removewhitespace, remove whitespace
            item = item.replace(" ", "");
        output += prefix + item + suffix + suffixToRemove;
    }
    if (suffixToRemove!=null)
        output = output.slice(0, (suffixToRemove.length*-1)); //ie remove the last ", "
    return output;
}

//12/21/18 1:24p
function BuildPageElements(table, codepage, fields) {
    var output = "";

    //UPDATE TABLE SCRIPT
    output += "function Update" + table + "Table() {\n";
    output += "	var obj = {};\n";
    output += "	//obj.SortField = \"timestamp\";\n";
    output += "	console.log(\"Update" + table + "Table() obj:\", obj);\n";
    output += "	$.ajax({\n";
    output += "		type: \"POST\",\n";
    output += "		url: \"" + codepage + ".aspx/BuildTable_" + table + "\",\n";
    output += "		data: JSON.stringify(obj),\n";
    output += "		contentType: \"application/json; charset=utf-8\",\n";
    output += "		success: function (data) {\n";
    output += "			console.log(\"Update" + table + "Table() success: \", data);\n";
    output += "			$(\"#" + table + "Div\").html(data.d);\n";
    output += "			//UpdateLabel(\"" + table + "OutputSpan\", \"green\", \"" + table + " table refreshed \" + GetDate());\n";
    output += "		},\n";
    output += "		error: function (msg) {\n";
    output += "			alert('Update" + table + "Table() AJAX Failure: ' + msg.statusText);\n";
    output += "			console.log(msg);\n";
    output += "			//UpdateLabel(\"" + table + "OutputSpan\", \"red\", \"" + table + " table refresh failed \" + GetDate());\n";
    output += "		},\n";
    output += "		dataType: 'json',\n";
    output += "		async: false\n";
    output += "	});\n";
    output += "}\n";
    output += "\n\n\n";

    //SUBMIT NEW SCRIPT
    output += BuildJSAddFunction(table, codepage, fields);
    output += "\n\n\n";

    //DISPLAY TABLE DIV
    output += "<h2>" + table + "</h2>\n";
    output += "<div id=\"" + table + "Div\" runat=\"server\" clientIDMode=\"static\"></div>\n";
    output += "\n\n\n";

    //SUBMIT NEW FORM
    output += "<h2>New " + table + "</h2>\n";
    output += "<div id=\"New" + table + "Div\" runat=\"server\" clientidmode=\"static\">\n";
    console.log("testing: ", fields);
    for (var i = 0; i < fields.length; i++) {
        if (fields[i].toLowerCase() == "notes") {
            output += "	<label style=\"display: inline-block; width: 100px;\">" + fields[i] + ":</label>\n";
            output += "	<textarea id=\"New" + table + "_" + fields[i] + "Input\"></textarea><br />\n";
        }
        else if (fields[i].toLowerCase() == "timestamp") {
            output += "	<label style=\"display: inline-block; width: 100px;\">" + fields[i] + ":</label>\n";
            output += "	<input type=\"datetime-local\" value=\"\" id=\"New" + table + "_" + fields[i] + "Input\" />\n";
        }
        else {
            output += "	<label style=\"display: inline-block; width: 100px;\">" + fields[i] + ":</label>\n";
            output += "	<input type=\"text\" value=\"\" id=\"New" + table + "_" + fields[i] + "Input\" />\n";
        }
    }
    output += "	<input type=\"button\" value=\"Submit\" onclick=\"New" + table + "_Submit()\" class=\"themedbutton\" />\n";
    output += "	<span id=\"New" + table + "Lbl\"></span>\n";
    output += "</div>\n";
    output += "\n\n\n";

    //C# !isPostBack
    output += "if (!IsPostBack)\n";
    output += "{\n";
    output += "" + table + "Div.InnerHtml = BuildTable_" + table + "();\n";
    output += "}\n";
    return output;
}

//12/21/18 1:29p
function ConvertCodeToString(input) {
    return input.replace("\"", "\\");
}

//runs all above C# functions, prints results to console
function BuildAll(table, fields) {
    var output = "";
    //output += "var table = '" + table + "';\n";
    //output += "var fields = '" + fields + "';\n\n";

    //C# functions
    output += BuildSelectFunction(table, fields) + "\n\n";
    output += BuildInsertFunction(table, fields) + "\n\n";
    output += BuildUpdateFunction(table, fields) + "\n\n";
    output += BuildDeleteFunction(table, fields[0]) + "\n\n";

    //build table
    output += BuildBuildTableFunction(table, fields) + "\n\n";
   
    //OBJECT
    output += BuildClassObject(table, fields) + "\n\n";
    output += BuildClassObjectContainer(table) + "\n\n";
    output += BuildSelectObjFunction(table, fields) + "\n\n";

    output += BuildBuildObjectTableFunction(table, fields) + "\n\n";

    //JS
    output += BuildJSAddFunction(table, fields) + "\n\n";
    output += BuildJSUpdateTableFunction(table,codepage) + "\n\n";

    //everything else
    output += BuildPageElements(table, fields) + "\n\n";

    //console.log(output);
    return output;
}

//runs all above C# functions, prints results to console
//3/12/19 10:48a
//5/6/20 9:28a UPDATED to use SQLProcess versions of the below functions
function BuildAll2(table, objectname,codepage, connectionstring, fields) {
    var output = "";
    //output += "var table = '" + table + "';\n";
    //output += "var fields = '" + fields + "';\n\n";

    //if (table.endsWith("s"))
    //    objectname = table.substring(0, table.length - 1);
    //else
    //    objectname = table;

    console.log("fields: ", fields);
    output += "//" + table;
    output += "//" + AppendToListItems(fields, "", "", ",") + "\n\n";

    //C# functions
   // output += BuildSelectFunction(table, fields, connectionstring) + "\n\n";
   // output += BuildBuildTableFunction(table, fields) + "\n\n";//build table

    //output += BuildInsertFunction(table, objectname, fields, connectionstring) + "\n\n";
    //output += BuildUpdateFunction(table, objectname, fields, connectionstring) + "\n\n";
    //output += BuildAddEditFunction2(table, objectname, fields, connectionstring) + "\n\n";
    output += BuildAddEditFunction3(table, objectname, fields) + "\n\n";
    //output += BuildDeleteFunction(table, objectname, fields[0], connectionstring) + "\n\n";
    output += BuildDeleteFunction2(table, objectname, fields[0]) + "\n\n";
    
    //OBJECT
    output += BuildClassObject(objectname, fields) + "\n\n";
    output += BuildClassObjectContainer(objectname) + "\n\n";
    //output += BuildSelectObjFunction(table, objectname,fields, connectionstring) + "\n\n";
    output += BuildSelectObjFunction3(table, objectname,fields) + "\n\n";

    output += BuildBuildObjectTableFunction(objectname, fields) + "\n\n";

    //JS
    //output += BuildJSAddFunction(table, fields) + "\n\n";
    //output += BuildJSUpdateTableFunction(table) + "\n\n";

    //everything else
    //output += BuildPageElements(table, codepage, fields) + "\n\n";
    //output += BuildBuildEditFormFunction(objectname, table, fields) + "\n\n";
    output += BuildBuildAddEditFormFunction(objectname, table, fields) + "\n\n";

    output += BuildJSUpdateTableFunction2(objectname, codepage, fields) + "\n\n";
    //output += BuildJSShowEditFormFunction(objectname, codepage, fields[0]) + "\n\n";
    output += BuildJSShowAddEditFormFunction(objectname, codepage, $.trim(fields[0]).replace(" ","")) + "\n\n";
    //output += BuildJSAddEditSubmitFunctions(objectname, codepage, fields) + "\n\n";
    output += BuildJSAddEditSubmitFunction2(objectname, codepage, fields) + "\n\n";
    
    //console.log(output);
    return output;
}

//TODO: add functions for generating the forms and JS functions 


//runs all above C# functions, prints results to console
//3/12/19 10:48a
//5/6/20 9:28a UPDATED to use SQLProcess versions of the below functions
//11/22/20 9:22a UPDATED with new inputs for view and pluralized objectname, along with new field customizations
function BuildAll3(table, view, objectname, pluralizedobjectname, codepage, connectionstring, fields, fieldcustomizations) {
    var output = "";
    //output += "var table = '" + table + "';\n";
    //output += "var fields = '" + fields + "';\n\n";

    //if (table.endsWith("s"))
    //    objectname = table.substring(0, table.length - 1);
    //else
    //    objectname = table;

    if (pluralizedobjectname == undefined || pluralizedobjectname == null || pluralizedobjectname == "")
        pluralizedobjectname = objectname = "s";

    var containerName = pluralizedobjectname + "Container";

    primaryKeyname = $.trim(fields[0]).replace(" ", "");

    if (fieldcustomizations != null) {
        for (var i = 0; i < fieldcustomizations.length; i++) { //loop through each field in array
            if (fieldcustomizations[i].isPk == true)
                primaryKeyname = fields[i];
        }
    }

    console.log("fields: ", fields);
    output += "//" + table;
    output += "//" + AppendToListItems(fields, "", "", ",") + "\n\n";

    //C# functions
    // output += BuildSelectFunction(table, fields, connectionstring) + "\n\n";
    // output += BuildBuildTableFunction(table, fields) + "\n\n";//build table

    //output += BuildInsertFunction(table, objectname, fields, connectionstring) + "\n\n";
    //output += BuildUpdateFunction(table, objectname, fields, connectionstring) + "\n\n";
    //output += BuildAddEditFunction2(table, objectname, fields, connectionstring) + "\n\n";
    output += BuildAddEditFunction3(table, objectname, fields, fieldcustomizations) + "\n\n"; //builds C# function for executing an insert or update query on a table
    //output += BuildDeleteFunction(table, objectname, fields[0], connectionstring) + "\n\n";
    output += BuildDeleteFunction2(table, objectname, primaryKeyname) + "\n\n"; //builds C# function for executing delete query on a table

    //OBJECT
    output += BuildClassObject(objectname, fields, fieldcustomizations) + "\n\n"; //builds C# class object for object
    output += BuildClassObjectContainer(objectname, containerName, primaryKeyname) + "\n\n"; //builds C# class object container for objects
    //output += BuildSelectObjFunction(table, objectname,fields, connectionstring) + "\n\n";
    output += BuildSelectObjFunction3(table, view, objectname, pluralizedobjectname, containerName, fields) + "\n\n"; //builds C# function to retrieve data fromt able and process it into container object

    output += BuildBuildObjectTableFunction(objectname, pluralizedobjectname, containerName, fields, fieldcustomizations) + "\n\n"; //builds C# code to process data from table into container object and turn that into an html table for display

    //JS
    //output += BuildJSAddFunction(table, fields) + "\n\n";
    //output += BuildJSUpdateTableFunction(table) + "\n\n";

    //everything else
    //output += BuildPageElements(table, codepage, fields) + "\n\n";
    //output += BuildBuildEditFormFunction(objectname, table, fields) + "\n\n";
    output += BuildBuildAddEditFormFunction(objectname, pluralizedobjectname, containerName, table, fields, fieldcustomizations) + "\n\n"; //build C# function that generates AddEditForm

    output += BuildJSUpdateTableFunction2(objectname, pluralizedobjectname, codepage, fields) + "\n\n"; //builds JS function that updates front end html table of data via ajax
    //output += BuildJSShowEditFormFunction(objectname, codepage, fields[0]) + "\n\n";
    output += BuildJSShowAddEditFormFunction(objectname, codepage, $.trim(fields[0]).replace(" ", "")) + "\n\n"; //builds JS function that generates and displays add/edit form for add/edit operation on table data via ajax
    //output += BuildJSAddEditSubmitFunctions(objectname, codepage, fields) + "\n\n";
    output += BuildJSAddEditSubmitFunction2(objectname, pluralizedobjectname, codepage, fields, fieldcustomizations) + "\n\n"; //builds JS function that executes add/edit operation on table data via ajax

    //console.log(output);
    return output;
}



//11/22/20 9:27a-9:44a
function BuildFieldCustomizations(fields) {
    output = "";
    console.log("fields: ", fields);
    //output += "//" + table;
    output += "//" + AppendToListItems(fields, "", "", ",") + "\n\n";
    output += "<table>";
    output += "<thead><tr>";
    output += "<th>Field</th>";
    output += "<th>isPk</th>";
    output += "<th>isEditable</th>";
    output += "<th>Datatype</th>";
    output += "</tr>";
    for (var i = 0; i < fields.length; i++) { //loop through each item in array
        output += "<tr>";
        output += "<th>" + fields[i] + "</th>";
        if (i == 0)
            checked = " checked ";
        else
            checked = "";
        output += "<td><input type='radio' name='SQLScriptFieldCustomizations_isPKRadio' id='SQLScriptFieldCustomizations_isPKRadio" + i + "' value='" + i + "' " + checked + "/></td>";
        output += "<td><input type='checkbox' id='SQLScriptFieldCustomizations_isEditableCheck" + i + "' value='" + i + "' checked='checked'/></td>";
        output += "<td><select id='SQLScriptFieldCustomizations_DatatypeInput" + i + "' onchange=\"SQLScriptFieldCustomizations_DatatypeInputChanged('" + i + "')\">" +
            "<option value='Text'>Text</option>" +
            "<option value='Number'>Number</option>" +
            "<option value='Bit'>Bit/Bool</option>" +
            "<option value='Date'>Date</option>" +
            "<option value='DateTime'>DateTime</option>" +
            "</select>" + 
            "<div id='FieldOptions_Text" + i + "'>" + 
                "Char Limit: <input type='number' id='FieldOptions_TextCharLimit" + i + "' style='width:55px;'/>  " + 
            "</div>" + 
            "<div id='FieldOptions_Number" + i + "' style='display:none;'>" +
                "Step (1, 0.1, 0.01, etc): <input type='number' id='FieldOptions_NumberStep" + i + "' style='width:55px;'/>  " +
                "Min: <input type='number' id='FieldOptions_NumberMin" + i + "' style='width:55px;'/>  " +
                "Max: <input type='number' id='FieldOptions_NumberMax" + i + "' style='width:55px;'/>  " + 
            "</div>" + 
            "<div id='FieldOptions_Bit" + i + "' style='display:none;'>" + 
                "Default: <input type='checkbox' id='FieldOptions_BitDefault" + i + "' />  " + 
            "</div>" + 
            "<div id='FieldOptions_Date" + i + "' style='display:none;'>" + //doesn't currently need any additional fields
            "</div>" + 
            "<div id='FieldOptions_DateTime" + i + "' style='display:none;'>" + //doesn't currently need any additional fields
            "</div>" + 
            "</td>";
        output += "</tr>";
    }
    output += "</thead>";
    output += "</table>";

    return output;

}